// runtime/host-adapter.js
var ADAPTED = /* @__PURE__ */ Symbol("maodou.api2.unmirrored");
var SVGNS = "http://www.w3.org/2000/svg";
var clamp = (x, a, b) => Math.min(b, Math.max(a, x));
var headingOf = (p) => p.facing === -1 ? -1 : 1;
var has = (o, k) => Object.prototype.hasOwnProperty.call(o, k);
var STYLE = `
:root{--shadow:rgba(27,22,38,.12);--tear:#5AAEF0;--heart:#F0567A;--dust:#A39DB0;--skin-eye:#00A870}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){--shadow:rgba(0,0,0,.32);--tear:#6BBDF7;--heart:#FF6F93;--dust:#5B6472;--skin-eye:#2FD59B}}
:root[data-theme="dark"]{--shadow:rgba(0,0,0,.32);--tear:#6BBDF7;--heart:#FF6F93;--dust:#5B6472;--skin-eye:#2FD59B}
.shadow{fill:var(--shadow)} .tearf{fill:var(--tear)} .p-heart{stroke:var(--heart)} .p-dust{stroke:var(--dust)} .eye{stroke:var(--skin-eye)}
svg.kit{position:absolute;inset:0;width:100%;height:100%;display:block;overflow:visible}
`;
function adaptNativeKit(nativeKit) {
  if (nativeKit?.[ADAPTED]) return nativeKit;
  if (typeof nativeKit?.createPet !== "function") {
    throw new TypeError("Maodou requires the native Coopanion API 2 createPet kit");
  }
  const result = {
    ...nativeKit,
    createBody: (host, opts) => createUnmirroredBody(nativeKit, host, opts)
  };
  Object.defineProperty(result, ADAPTED, { value: true });
  return Object.freeze(result);
}
function createUnmirroredBody(nativeKit, host, opts = {}) {
  if (!host?.root?.ownerDocument || typeof host.bounds !== "function") {
    throw new TypeError("A native API 2 host with root and bounds() is required");
  }
  const figure = opts.figure;
  if (typeof figure?.draw !== "function") throw new TypeError("figure.draw is required; no placeholder figure is created");
  const doc = host.root.ownerDocument;
  const style = doc.createElement("style");
  style.textContent = STYLE + (opts.css ?? "");
  const skinStyle = doc.createElement("style");
  doc.head.appendChild(style);
  doc.head.appendChild(skinStyle);
  const svg = doc.createElementNS(SVGNS, "svg");
  svg.setAttribute("class", "kit");
  svg.setAttribute("aria-hidden", "true");
  const shadowEl = doc.createElementNS(SVGNS, "ellipse");
  shadowEl.setAttribute("class", "shadow");
  for (const name of ["cx", "cy", "rx", "ry"]) shadowEl.setAttribute(name, "0");
  const petG = doc.createElementNS(SVGNS, "g");
  const fxG = doc.createElementNS(SVGNS, "g");
  svg.appendChild(shadowEl);
  svg.appendChild(petG);
  svg.appendChild(fxG);
  host.root.appendChild(svg);
  const start = host.start ?? {};
  let disposed = false, dialogOpen = false, ctl;
  let renderContext = null, renderedFrames = 0, lastFrame = null, lastDt = 0;
  let overrideYaw = null, yaw = 0, yawV = 0, yawTarget = 0;
  let turnUntil = -Infinity, turnHeading = start.facing === -1 ? -1 : 1;
  let previousHeading = turnHeading;
  let activePointerId = null, lastPointer = null, lastRelease = null;
  const o = opts.orientation ?? {};
  const amount = (key, fallback) => Number.isFinite(o[key]) ? clamp(o[key], 0, 1) : fallback;
  const idleYaw = amount("idleYaw", 0.2), walkYaw = amount("walkYaw", 0.72);
  const runYaw = amount("runYaw", 0.9), turnYaw = amount("turnYaw", 0.8);
  const omega = Number.isFinite(o.omega) ? clamp(o.omega, 2, 30) : 12;
  function resolveYawTarget() {
    if (overrideYaw !== null) return overrideYaw;
    const p = ctl.pet, heading = headingOf(p);
    if (p.mode === "walk" || p.mode === "run") return heading * (p.mode === "run" ? runYaw : walkYaw);
    if (ctl.time < turnUntil) return turnHeading * turnYaw;
    const gaze = clamp((p.look[0] || 0) * heading / 5, -1, 1);
    return gaze * (p.mode === "look" ? turnYaw : idleYaw);
  }
  function advanceYaw(dt) {
    const heading = headingOf(ctl.pet);
    if (heading !== previousHeading) {
      turnHeading = heading;
      turnUntil = ctl.time + 1.1;
      previousHeading = heading;
    }
    yawTarget = resolveYawTarget();
    const d = yaw - yawTarget, b = yawV + omega * d, e = Math.exp(-omega * dt);
    const next = yawTarget + (d + b * dt) * e;
    yawV = (yawV - omega * b * dt) * e;
    yaw = clamp(next, -1, 1);
    if (next !== yaw) yawV = 0;
  }
  function wrappedDraw(group, face, frame) {
    const c = renderContext;
    if (!c) throw new Error("Native draw must run inside the positive-scale adapter");
    const heading = c.heading;
    const lookScreen = [(frame.look?.[0] || 0) * heading, frame.look?.[1] || 0];
    const legsScreen = (frame.legs || []).map(([hx, hy, fx, fy]) => [hx, hy, hx + (fx - hx) * heading, fy]);
    const out = {
      ...frame,
      facing: c.facing,
      lean: frame.lean * c.facing,
      heading,
      viewYaw: yaw,
      viewYawTarget: yawTarget,
      viewYawOverride: overrideYaw,
      lookScreen,
      legsScreen,
      swingScreen: (frame.swing || 0) * Math.sign(c.facing || 1),
      dt: lastDt
    };
    lastFrame = out;
    figure.draw(group, face, out);
  }
  const proxyFigure = new Proxy(figure, {
    get(target, key) {
      if (key === "draw") return wrappedDraw;
      if (key === "groupTilt") return (mode, tilt, lean) => {
        const correctedLean = lean * (renderContext?.facing ?? 1);
        return typeof target.groupTilt === "function" ? target.groupTilt(mode, tilt, correctedLean) : tilt + correctedLean;
      };
      const value = Reflect.get(target, key, target);
      return typeof value === "function" ? value.bind(target) : value;
    }
  });
  try {
    if (opts.skinCss && start.skin) skinStyle.textContent = opts.skinCss(start.skin);
    ctl = nativeKit.createPet({ petG, shadowEl, fxG }, {
      ...opts,
      figure: proxyFigure,
      skin: start.skin ?? null,
      startX: start.x,
      enter: start.enter,
      bounds: host.bounds,
      onEvent: host.emit,
      sfx: { play: host.sound },
      dialogOpen: () => dialogOpen
    });
    if (start.facing === 1 || start.facing === -1) ctl.pet.facing = ctl.pet.faceVis = start.facing;
  } catch (error) {
    svg.remove();
    style.remove();
    skinStyle.remove();
    throw error;
  }
  function render() {
    const facing = ctl.pet.faceVis;
    renderContext = { facing, heading: headingOf(ctl.pet) };
    ctl.pet.faceVis = 1;
    try {
      ctl.render();
      renderedFrames++;
    } finally {
      ctl.pet.faceVis = facing;
      renderContext = null;
    }
  }
  const pointerMatches = (p) => activePointerId === null || p?.pointerId == null || p.pointerId === activePointerId;
  const validPoint = (p) => Number.isFinite(p?.x) && Number.isFinite(p?.y);
  function endPointer(p, reason, cancel = false) {
    if (!pointerMatches(p)) return false;
    const wasPressing = ctl.pressing, wasDragging = ctl.pet.mode === "drag";
    if (cancel) {
      const foot = ctl.toStage(128, 256), S = ctl.bounds.S;
      ctl.dropAt(wasDragging ? { x: foot.x, y: foot.y - 220 * S } : p ?? lastPointer ?? { x: 0, y: 0 });
      ctl.pet.cursor = "";
    } else ctl.pointerUp(p);
    activePointerId = null;
    if (wasPressing) lastRelease = { reason, cancel, wasDragging, time: ctl.time, pointerTime: Number.isFinite(p?.t) ? p.t : null };
    return wasPressing;
  }
  const onBlur = () => {
    if (ctl.pressing) endPointer(null, "frame-blur", true);
  };
  const onVisibility = () => {
    if (doc.visibilityState === "hidden" && ctl.pressing) endPointer(null, "frame-hidden", true);
  };
  doc.defaultView?.addEventListener?.("blur", onBlur);
  doc.defaultView?.addEventListener?.("pagehide", onBlur);
  doc.addEventListener?.("visibilitychange", onVisibility);
  const body = {
    step(dt) {
      if (disposed) return;
      lastDt = Number.isFinite(dt) && dt > 0 ? dt : 0;
      ctl.step(dt);
      if (lastDt) advanceYaw(lastDt);
      render();
    },
    layout() {
      const layout = ctl.layout();
      return { ...layout, moving: layout.moving || Math.abs(yaw - yawTarget) > 2e-3 || Math.abs(yawV) > 0.01 };
    },
    resize: () => ctl.resize(),
    do(word) {
      const result = ctl.doWord(word);
      if (result && word === "turn") {
        turnHeading = headingOf(ctl.pet);
        turnUntil = ctl.time + 1.1;
      }
      return result;
    },
    words: [
      ...nativeKit.KIT_EXPRESSIONS ?? [],
      ...nativeKit.KIT_MOTIONS ?? [],
      ...Object.keys(opts.words ?? {}).filter((w) => opts.words[w]?.expression || opts.words[w]?.motion)
    ],
    walk: (x, run, id) => ctl.walkTo(x, run, id),
    stopWalk: (id) => ctl.stopWalk(id),
    pointer(type, p) {
      if (disposed || !pointerMatches(p)) return false;
      if (type === "down") {
        if (!validPoint(p) || ctl.pressing || p?.isPrimary === false || Number.isFinite(p?.button) && p.button !== 0) return false;
        const accepted = ctl.pointerDown(p);
        if (accepted) {
          activePointerId = p.pointerId ?? null;
          lastPointer = { ...p };
        }
        return accepted;
      }
      if (type === "move") {
        if (!validPoint(p)) return false;
        if (ctl.pressing && p.buttons === 0) endPointer(p, "move-buttons-zero", true);
        lastPointer = { ...p };
        return ctl.pointerMove(p);
      }
      if (type === "up") return endPointer(p, "up");
      if (type === "cancel") return endPointer(p, p?.reason ?? "cancel", true);
      if (type === "leave") {
        if (ctl.pressing && p?.buttons === 0) endPointer(p, "leave-buttons-zero", true);
        ctl.pointerLeave();
      }
    },
    drop(p) {
      activePointerId = null;
      lastRelease = { reason: "host-drop", cancel: true, time: ctl.time };
      return ctl.dropAt(p);
    },
    shift(dx, dy) {
      if (lastPointer) {
        lastPointer.x += dx;
        lastPointer.y += dy;
      }
      return ctl.shiftDrag(dx, dy);
    },
    place(x, facing) {
      if (ctl.pet.mode === "drag" || ctl.pet.mode === "air") return;
      const { minX, maxX } = ctl.bounds;
      ctl.pet.x = ctl.pet.target = clamp(x, minX, maxX);
      if (facing === 1 || facing === -1) ctl.pet.facing = ctl.pet.faceVis = facing;
    },
    set(s = {}) {
      if (s.roam) ctl.setRoam(s.roam);
      if (typeof s.hold === "number") ctl.holdRoam(s.hold);
      if (typeof s.dialogOpen === "boolean") dialogOpen = s.dialogOpen;
      if (typeof s.listening === "boolean") ctl.setListening(s.listening);
      if (typeof s.thinking === "boolean") ctl.setThinking(s.thinking);
      if (typeof s.thoughtShown === "boolean") ctl.setThoughtShown(s.thoughtShown);
      if (s.skin) {
        ctl.setSkin(s.skin);
        if (opts.skinCss) skinStyle.textContent = opts.skinCss(s.skin);
      }
      if (s.theme) doc.documentElement.dataset.theme = s.theme;
      if (has(s, "viewYaw")) {
        if (s.viewYaw !== null && !Number.isFinite(s.viewYaw)) throw new TypeError("viewYaw must be finite or null");
        overrideYaw = s.viewYaw === null ? null : clamp(s.viewYaw, -1, 1);
        yawTarget = resolveYawTarget();
        if (s.viewYawImmediate === true) {
          yaw = yawTarget;
          yawV = 0;
        }
      }
    },
    cue(kind) {
      if (kind === "perk") {
        ctl.pet.sqv += 0.6;
        ctl.setExpr("surprised", 0.5);
      } else if (kind === "heard") ctl.pet.sqv += 0.9;
      else if (kind === "cheer") ctl.setExpr("happy");
      else if (kind === "bounce") ctl.pet.sqv += 1.2;
    },
    talk: () => ctl.talk(),
    setScheme: (id, options) => figure.setScheme?.(id, options),
    get z() {
      return figure.colors?.z ?? null;
    },
    inspect() {
      return {
        adapter: "maodou-api2-unmirrored-1.3.1",
        disposed,
        renderedFrames,
        pointer: { pressing: ctl.pressing, activePointerId, lastRelease: lastRelease ? { ...lastRelease } : null },
        time: ctl.time,
        mode: ctl.pet.mode,
        heading: headingOf(ctl.pet),
        nativeFacing: ctl.pet.faceVis,
        viewYaw: yaw,
        viewYawTarget: yawTarget,
        viewYawOverride: overrideYaw,
        xf: ctl.pet.xf ? { ...ctl.pet.xf } : null,
        frame: lastFrame ? { ...lastFrame } : null
      };
    },
    dispose() {
      if (disposed) return;
      disposed = true;
      doc.defaultView?.removeEventListener?.("blur", onBlur);
      doc.defaultView?.removeEventListener?.("pagehide", onBlur);
      doc.removeEventListener?.("visibilitychange", onVisibility);
      try {
        figure.dispose?.();
      } finally {
        svg.remove();
        style.remove();
        skinStyle.remove();
      }
    }
  };
  return body;
}

// runtime/words.js
var freeze = (value) => {
  if (value && typeof value === "object" && !Object.isFrozen(value)) {
    Object.values(value).forEach(freeze);
    Object.freeze(value);
  }
  return value;
};
var expression = (id, label, description, en, extra = {}) => ({ id, kind: "expression", label, description, en, seconds: 0.9, ...extra });
var motion = (id, label, seconds, description, en, extra = {}) => ({ id, kind: "motion", label, description, en, seconds, ...extra });
var CORE_EXPRESSION_DEFINITIONS = freeze([
  expression("neutral", "\u5E73\u9759", "\u653E\u677E\u7684\u9752\u8272\u773C\u775B\u4E0E\u5C0F\u5634\uFF0C\u8F7B\u8F7B\u547C\u5438\u3002", "Relaxed cyan eyes, a small resting mouth, and gentle breathing."),
  expression("happy", "\u5F00\u5FC3", "\u5F00\u5FC3\u5730\u5F2F\u8D77\u773C\u775B\uFF0C\u5C0F\u5634\u542B\u7B11\uFF0C\u8033\u6735\u8F7B\u8F7B\u56DE\u5E94\u3002", "Happy curved eyes, a small smile, and a gentle ear response."),
  expression("wink", "\u7728\u773C", "\u5355\u773C\u7728\u4E00\u4E0B\uFF0C\u53E6\u4E00\u53EA\u9752\u8272\u773C\u775B\u4FDD\u7559\u3002", "A one-eye wink while the other cyan eye stays visible."),
  expression("love", "\u559C\u6B22", "\u6E29\u67D4\u5730\u671B\u5411\u4F60\uFF0C\u8138\u988A\u5FAE\u7EA2\uFF0C\u59FF\u6001\u4EB2\u8FD1\u3002", "An affectionate gaze, a little blush, and a welcoming pose."),
  expression("shy", "\u5BB3\u7F9E", "\u89C6\u7EBF\u8F7B\u8F7B\u8EB2\u5F00\uFF0C\u8138\u7EA2\u5E76\u5FAE\u5FAE\u4F4E\u5934\u3002", "Averted gaze, blushing cheeks, and a small head dip."),
  expression("surprised", "\u60CA\u8BB6", "\u9752\u8272\u773C\u775B\u7741\u5706\uFF0C\u5C0F\u5634\u77ED\u6682\u5F20\u5F00\u3002", "Widened cyan eyes and a briefly open small mouth."),
  expression("angry", "\u751F\u6C14", "\u7709\u773C\u6536\u7D27\uFF0C\u5C0F\u5634\u8BA4\u771F\u62BF\u8D77\uFF0C\u514B\u5236\u5730\u9F13\u8D77\u52B2\u3002", "Tighter brows and eyes with a small determined mouth."),
  expression("sad", "\u96BE\u8FC7", "\u7709\u5C3E\u653E\u4F4E\u3001\u89C6\u7EBF\u4E0B\u5782\uFF0C\u8033\u6735\u548C\u91CD\u5FC3\u8F7B\u8F7B\u6C89\u4E0B\u3002", "Lowered brows and gaze with softly drooping ears and posture."),
  expression("sleepy", "\u72AF\u56F0", "\u773C\u76AE\u6162\u6162\u53D8\u6C89\uFF0C\u5E26\u4E00\u6B21\u5C0F\u5C0F\u7684\u54C8\u6B20\u3002", "Heavy eyelids and a small, slow yawn."),
  expression("thinking", "\u601D\u8003", "\u89C6\u7EBF\u7565\u5411\u4E0A\u504F\uFF0C\u4FDD\u6301\u5C0F\u53E3\uFF0C\u8F7B\u8F7B\u6B6A\u5934\u601D\u8003\u3002", "A slightly raised gaze and a thoughtful small head tilt."),
  expression("smug", "\u5F97\u610F", "\u773C\u76AE\u7565\u6536\uFF0C\u5634\u89D2\u8F7B\u626C\uFF0C\u9732\u51FA\u4E00\u70B9\u5C0F\u5F97\u610F\u3002", "Slightly lowered eyelids and a restrained smug smile."),
  expression("pout", "\u561F\u5634", "\u5C0F\u5634\u5658\u8D77\uFF0C\u89C6\u7EBF\u8F6C\u5F00\uFF0C\u8138\u988A\u5FAE\u5FAE\u53D1\u7EA2\u3002", "A small pout with an averted gaze and a little blush."),
  expression("worried", "\u62C5\u5FC3", "\u7709\u95F4\u8F7B\u8E59\uFF0C\u773C\u775B\u4FDD\u7559\u7EB5\u5411\u5F62\u72B6\uFF0C\u7D27\u5F20\u5730\u671B\u7740\u524D\u65B9\u3002", "Worried brows and attentive eyes that keep their tall shape."),
  expression("determined", "\u8BA4\u771F", "\u773C\u795E\u4E13\u6CE8\uFF0C\u7709\u6BDB\u7A0D\u538B\uFF0C\u5C0F\u722A\u7A33\u7A33\u6536\u597D\u3002", "Focused eyes, slightly lowered brows, and steady little paws."),
  expression("flustered", "\u614C\u5F20", "\u773C\u775B\u77ED\u6682\u6536\u7D27\uFF0C\u8138\u988A\u6CDB\u7EA2\uFF0C\u968F\u540E\u7F13\u7F13\u56DE\u7A33\u3002", "A brief flustered squint and blush followed by a gentle recovery."),
  expression("scared", "\u5BB3\u6015", "\u7741\u5927\u773C\u775B\uFF0C\u7709\u6BDB\u4E0A\u63D0\uFF0C\u8EAB\u4F53\u8F7B\u8F7B\u7F29\u8D77\u3002", "Wide eyes, raised brows, and a small protective huddle."),
  expression("excited", "\u5174\u594B", "\u773C\u775B\u66F4\u7CBE\u795E\uFF0C\u5C0F\u5634\u5F00\u5FC3\uFF0C\u59FF\u6001\u8F7B\u5FEB\u5730\u63D0\u8D77\u3002", "Bright, alert eyes and an excited upward posture."),
  expression("cry", "\u54ED\u6CE3", "\u4FDD\u7559\u5B8C\u6574\u9752\u8272\u773C\u5F62\uFF0C\u7709\u6BDB\u59D4\u5C48\uFF0C\u5C0F\u6CEA\u6EF4\u4ECE\u773C\u5E95\u843D\u4E0B\u3002", "Full cyan eyes, sad brows, and small tears falling from the lower lids."),
  expression("confused", "\u7591\u60D1", "\u4E24\u4FA7\u7709\u773C\u7565\u6709\u4E0D\u540C\uFF0C\u5E26\u4E00\u70B9\u4E0D\u89E3\u7684\u6B6A\u5934\u3002", "Slightly asymmetric brows and eyes with a puzzled head tilt.")
]);
var CORE_MOTION_DEFINITIONS = freeze([
  motion("stand", "\u7AD9\u8D77", 1.2, "\u4ECE\u5750\u59FF\u6216\u56F0\u5026\u59FF\u52BF\u7F13\u7F13\u7AD9\u7A33\u3002", "Returns gently to a standing posture."),
  motion("jump", "\u8DF3\u8D77\u6765", 1.2, "\u8E72\u4E0B\u84C4\u529B\u540E\u539F\u5730\u8D77\u8DF3\uFF0C\u843D\u5730\u65F6\u67D4\u8F6F\u56DE\u5F39\u3002", "Crouches, jumps on the spot, and settles softly after landing."),
  motion("hop", "\u5C0F\u8DF3", 0.9, "\u505A\u4E00\u6B21\u5E45\u5EA6\u8F83\u5C0F\u7684\u8F7B\u8DF3\u3002", "A small, light hop."),
  motion("look", "\u5F20\u671B", 2.7, "\u5728\u6709\u9650\u4FA7\u5411\u5173\u952E\u5F62\u72B6\u4E4B\u95F4\u89C2\u5BDF\u5468\u56F4\u3002", "Looks around within the authored side-view range."),
  motion("turn", "\u8F6C\u8EAB", 1.2, "\u6539\u53D8\u671D\u5411\uFF0C\u5934\u8033\u8FDE\u7EED\u8F6C\u52A8\u800C\u4E0D\u538B\u6210\u8584\u7247\u3002", "Changes heading through continuous head and ear movement."),
  motion("nod", "\u70B9\u5934", 0.8, "\u8F7B\u8F7B\u4F4E\u5934\u5E94\u7B54\uFF0C\u7136\u540E\u56DE\u5230\u539F\u4F4D\u3002", "A gentle nod followed by a return to rest."),
  motion("shake", "\u6447\u5934", 0.8, "\u514B\u5236\u5730\u5DE6\u53F3\u6447\u5934\u3002", "A restrained side-to-side head shake."),
  motion("spin", "\u5C0F\u8F6C\u52A8", 0.8, "\u5728\u6B63\u9762\u4E0E\u4FA7\u9762\u95F4\u8F7B\u5FEB\u8F6C\u52A8\uFF0C\u4E0D\u5C55\u793A\u80CC\u9762\u3002", "A small turn between front and side views, without a back view."),
  motion("sit", "\u5750\u4E0B", 0.8, "\u7F13\u7F13\u5750\u4E0B\uFF0C\u5E76\u4FDD\u6301\u5750\u59FF\u3002", "Sits down and holds the seated pose.", { lasting: true }),
  motion("sleep", "\u7761\u89C9", 0.8, "\u5408\u773C\u4F11\u606F\uFF0C\u7EF4\u6301\u7F13\u6162\u547C\u5438\u3002", "Closes the eyes and rests with slow breathing.", { lasting: true }),
  motion("dizzy", "\u6655\u4E4E\u4E4E", 3.2, "\u77ED\u6682\u6655\u4E4E\uFF0C\u8EAB\u4F53\u4E0E\u8033\u6735\u8F7B\u8F7B\u6643\u52A8\u3002", "A brief dizzy wobble through the body and ears."),
  motion("walk", "\u6563\u6B65", 12, "\u6309\u7167\u539F\u751F\u8EAB\u4F53\u8DEF\u5F84\u8D70\u4E00\u6BB5\uFF0C\u811A\u6B65\u4E0E\u8033\u5C3E\u8DDF\u968F\u79FB\u52A8\u3002", "Walks using the native body path with coordinated feet, ears, and tail."),
  motion("run", "\u8DD1\u8D77\u6765", 12, "\u5411\u53E6\u4E00\u8FB9\u8F7B\u5FEB\u8DD1\u52A8\uFF0C\u5E76\u5728\u505C\u6B62\u65F6\u6536\u7A33\u3002", "Runs towards the other side and settles on stopping."),
  motion("wave", "\u62DB\u624B", 1.7, "\u4E3E\u8D77\u4E00\u53EA\u77ED\u722A\u6325\u4E00\u6325\u3002", "Raises one short paw for a small wave."),
  motion("bow", "\u97A0\u8EAC", 1.7, "\u5408\u773C\u5E76\u8F7B\u8F7B\u4F4E\u5934\u81F4\u610F\u3002", "Closes the eyes and dips the head in greeting."),
  motion("shiver", "\u53D1\u6296", 1.9, "\u7F29\u8D77\u8EAB\u5B50\u505A\u5C0F\u5E45\u6296\u52A8\uFF0C\u7136\u540E\u653E\u677E\u3002", "Huddles for a small shiver, then relaxes."),
  motion("flap", "\u6251\u817E", 1.5, "\u77ED\u6682\u8D77\u8DF3\uFF0C\u53CC\u8033\u968F\u8EAB\u4F53\u8F7B\u8F7B\u6251\u52A8\u3002", "A brief hop with a soft response through both ears."),
  motion("dance", "\u8DF3\u821E", 3.4, "\u8E29\u7740\u8282\u594F\u5DE6\u53F3\u6446\u52A8\uFF0C\u8033\u5C3E\u5E26\u6709\u67D4\u8F6F\u5EF6\u8FDF\u3002", "Rhythmic side-to-side steps with soft ear and tail follow-through.")
]);
var CUSTOM_EXPRESSION_DEFINITIONS = freeze([
  expression("cozy", "\u5B89\u5FC3", "\u773C\u5F27\u67D4\u548C\uFF0C\u5634\u89D2\u653E\u677E\uFF0C\u53CC\u8033\u5B89\u9759\u5730\u5782\u843D\u3002", "Soft eye curves, a relaxed mouth, and calmly resting ears.", { like: "content", holdSeconds: 3.4 }),
  expression("curious", "\u597D\u5947", "\u5E26\u7740\u4E0A\u626C\u7684\u89C6\u7EBF\u8F7B\u8F7B\u63A2\u770B\uFF0C\u7709\u773C\u6BD4\u601D\u8003\u66F4\u8212\u5C55\u3002", "An inquisitive upward gaze with more open brows than the thinking face.", { like: "thinking", holdSeconds: 3.4 }),
  expression("bashful", "\u7F9E\u559C", "\u5F00\u5FC3\u53C8\u5BB3\u7F9E\u5730\u6536\u8D77\u5C0F\u722A\uFF0C\u773C\u5F27\u548C\u8138\u7EA2\u4E00\u8D77\u6E10\u5165\u3002", "A shy, happy smile with tucked paws and a gently arriving blush.", { like: "shy", holdSeconds: 3.4 }),
  expression("pleading", "\u59D4\u5C48", "\u7EB5\u5411\u9752\u773C\u7565\u542B\u6CEA\u610F\uFF0C\u7709\u6BDB\u67D4\u8F6F\u5730\u62AC\u8D77\uFF0C\u5C0F\u5634\u8F7B\u62BF\u3002", "Tall cyan eyes, gently raised sad brows, and a small pleading mouth.", { like: "worried", holdSeconds: 3.4 }),
  expression("proud", "\u5C0F\u5F97\u610F", "\u7A0D\u7A0D\u62AC\u5934\uFF0C\u773C\u775B\u4ECD\u7136\u67D4\u548C\uFF0C\u5C0F\u5634\u5E26\u4E00\u70B9\u81EA\u8C6A\u3002", "A modest head lift with soft eyes and a quietly proud mouth.", { like: "smug", holdSeconds: 3.4 }),
  expression("sparkle", "\u671F\u5F85", "\u4FDD\u7559\u9752\u8272\u773C\u775B\uFF0C\u8F7B\u8F7B\u63D0\u7709\u7741\u773C\uFF0C\u7565\u5411\u524D\u503E\u7740\u7B49\u5F85\u3002", "Keeps the cyan eyes, gently raises the brows and lids, and leans forward expectantly.", { like: "excited", holdSeconds: 3.4 })
]);
var CUSTOM_MOTION_DEFINITIONS = freeze([
  motion("ear-wave", "\u8033\u6735\u62DB\u624B", 2.2, "\u4E00\u53EA\u8033\u6735\u4E3B\u52A8\u62AC\u8D77\u62DB\u624B\uFF0C\u53E6\u4E00\u53EA\u8033\u6735\u8F7B\u8F7B\u5E73\u8861\u3002", "One ear waves while the other softly balances the pose.", { face: "happy" }),
  motion("ear-fold", "\u62B1\u8033", 2.7, "\u53CC\u8033\u67D4\u8F6F\u5730\u5411\u5185\u6298\uFF0C\u5C0F\u722A\u9760\u8FD1\u8033\u8FB9\u3002", "Folds both ears softly inward while the paws move closer.", { face: "cozy" }),
  motion("cuddle", "\u8D34\u8FD1\u62B1\u62B1", 3, "\u8EAB\u4F53\u5411\u524D\u4EB2\u8FD1\uFF0C\u5C0F\u722A\u5408\u62E2\uFF0C\u8033\u6735\u8F7B\u67D4\u5305\u4F4F\u52A8\u4F5C\u3002", "Leans closer with gathered paws and softly surrounding ears.", { face: "bashful" }),
  motion("peek", "\u5DE6\u53F3\u63A2\u5934", 2.8, "\u5148\u5411\u4E00\u4FA7\u63A2\u5934\uFF0C\u518D\u7ECF\u8FC7\u6B63\u9762\u89C2\u5BDF\u53E6\u4E00\u4FA7\u3002", "Peeks to one side, then crosses the front to inspect the other.", { face: "curious" }),
  motion("stretch", "\u4F38\u61D2\u8170", 3.2, "\u7F13\u7F13\u4F38\u5C55\u8EAB\u4F53\u548C\u53CC\u8033\uFF0C\u505C\u7559\u7247\u523B\u540E\u677E\u4E0B\u6765\u3002", "Slowly stretches the body and ears, holds briefly, then relaxes.", { face: "neutral" }),
  motion("sway", "\u8F7B\u8F7B\u6447\u6446", 3, "\u8EAB\u4F53\u5E73\u7F13\u5730\u5DE6\u53F3\u6447\u6446\uFF0C\u8033\u5C3E\u7565\u665A\u8DDF\u4E0A\u3002", "Sways slowly from side to side with delayed ear and tail movement.", { face: "cozy" }),
  motion("bounce", "\u5C3E\u5DF4\u5F39\u8DF3", 2.4, "\u5C3E\u5DF4\u5148\u8F7B\u8F7B\u5F39\u52A8\uFF0C\u5E26\u52A8\u8EAB\u4F53\u505A\u5C0F\u5E45\u56DE\u5F39\u3002", "A small tail bounce leads into a restrained body rebound.", { face: "happy" }),
  motion("doze", "\u6253\u778C\u7761", 3.6, "\u773C\u76AE\u6E10\u6C89\uFF0C\u5934\u90E8\u70B9\u843D\u540E\u8F7B\u8F7B\u56DE\u795E\u3002", "The eyelids grow heavy and the head dips before gently recovering.", { face: "sleepy" }),
  motion("greet", "\u8F7B\u5FEB\u62DB\u547C", 2.5, "\u62AC\u5934\u770B\u5411\u4F60\uFF0C\u914D\u5408\u77ED\u722A\u4E0E\u8033\u6735\u7ED9\u51FA\u8F7B\u5FEB\u56DE\u5E94\u3002", "Looks up with a coordinated paw and ear greeting.", { face: "happy" }),
  motion("celebrate", "\u96C0\u8DC3\u5E86\u795D", 3.3, "\u5C0F\u722A\u3001\u8033\u5C3E\u4E0E\u91CD\u5FC3\u4EA4\u66FF\u4E0A\u626C\uFF0C\u5F00\u5FC3\u5E86\u795D\u540E\u56DE\u7A33\u3002", "Celebrates with alternating lifts through paws, ears, tail, and posture.", { face: "excited" })
]);
var CORE_EXPRESSIONS = freeze(CORE_EXPRESSION_DEFINITIONS.map((w) => w.id));
var CORE_MOTIONS = freeze(CORE_MOTION_DEFINITIONS.map((w) => w.id));
var CUSTOM_EXPRESSION_IDS = freeze(CUSTOM_EXPRESSION_DEFINITIONS.map((w) => w.id));
var CUSTOM_MOTION_IDS = freeze(CUSTOM_MOTION_DEFINITIONS.map((w) => w.id));
var WORD_DEFINITIONS = freeze([...CORE_EXPRESSION_DEFINITIONS, ...CUSTOM_EXPRESSION_DEFINITIONS, ...CORE_MOTION_DEFINITIONS, ...CUSTOM_MOTION_DEFINITIONS]);
var WORD_LABELS = freeze(Object.fromEntries(WORD_DEFINITIONS.map((w) => [w.id, w.label])));
var WORD_DESCRIPTIONS = freeze(Object.fromEntries(WORD_DEFINITIONS.map((w) => [w.id, w.description])));
var CUSTOM_WORDS = freeze(Object.fromEntries([
  ...CUSTOM_EXPRESSION_DEFINITIONS.map((w) => [w.id, { expression: { like: w.like, seconds: w.holdSeconds } }]),
  ...CUSTOM_MOTION_DEFINITIONS.map((w) => [w.id, { motion: { seconds: w.seconds, face: w.face } }])
]));
var VOCAB = freeze(WORD_DEFINITIONS.map((w) => ({
  id: w.id,
  kind: w.kind,
  names: { zh: [w.label] },
  about: { zh: w.description, en: w.en },
  seconds: w.seconds,
  ...w.lasting ? { lasting: true } : {}
})));
var PERSONALITY_AXES = freeze([{ id: "personality", name: { zh: "\u6027\u683C", en: "Personality" }, options: [
  { id: "gentle", name: { zh: "\u6E29\u67D4", en: "Gentle" }, accent: "#90cada" },
  { id: "lively", name: { zh: "\u6D3B\u6CFC", en: "Lively" }, accent: "#90cada" }
] }]);
var VOCABULARY_STATUS = freeze({
  registrationOnly: true,
  visualValidationClaimed: false,
  nativeExpressions: 19,
  customExpressions: 6,
  nativeMotions: 18,
  customMotions: 10,
  expressions: 25,
  motions: 28,
  total: 53
});

// runtime/atlas-renderer.js
var STRIDE = 20;
var STRIDE_BYTES = STRIDE * 4;
var LIMIT_VERTICES = 65535;
var clamp01 = (value) => Math.min(1, Math.max(0, value));
var clock = () => globalThis.performance?.now?.() ?? Date.now();
var own = (object, key) => Object.prototype.hasOwnProperty.call(object, key);
function finiteNumber(value, label) {
  if (typeof value !== "number" || !Number.isFinite(value)) throw new TypeError(label + " must be finite.");
  return value;
}
function numericArray(value, length, label) {
  if (!Array.isArray(value) && !(ArrayBuffer.isView(value) && !(value instanceof DataView))) {
    throw new TypeError(label + " must be a numeric array.");
  }
  if (length !== null && value.length !== length) throw new RangeError(label + " has an unexpected length.");
  for (let i = 0; i < value.length; i++) finiteNumber(value[i], label + "[" + i + "]");
  return value instanceof Float32Array ? value : new Float32Array(value);
}
function scalarOrArray(value, count, label) {
  return typeof value === "number" ? clamp01(finiteNumber(value, label)) : numericArray(value, count, label);
}
function normalizeView(value) {
  const view = Array.from(numericArray(value, 4, "view"));
  if (view[2] <= view[0] || view[3] <= view[1]) throw new RangeError("view must have positive width and height.");
  return view;
}
function normalizeOutline(value = {}) {
  if (value === false) return { enabled: false, width: 0, color: [0, 0, 0, 0] };
  const color = Array.from(numericArray(value.color ?? [0.49, 0.34, 0.39, 1], 4, "outline.color"), clamp01);
  const width = finiteNumber(value.width ?? 1, "outline.width");
  if (width < 0) throw new RangeError("outline.width must be nonnegative model units.");
  return { enabled: value.enabled !== false && width > 0 && color[3] > 0, width, color };
}
function fitBackingSize(width, height, maxEdge = 512) {
  finiteNumber(width, "width");
  finiteNumber(height, "height");
  finiteNumber(maxEdge, "maxEdge");
  if (width <= 0 || height <= 0 || maxEdge < 1 || maxEdge > 640) {
    throw new RangeError("Positive dimensions and maxEdge in [1,640] are required.");
  }
  const scale = Math.min(1, Math.floor(maxEdge) / Math.max(width, height));
  return [Math.max(1, Math.floor(width * scale)), Math.max(1, Math.floor(height * scale))];
}
function createAtlasBatch(scene = { parts: [], masks: [] }) {
  if (!Array.isArray(scene.parts)) throw new TypeError("scene.parts must be an array.");
  const masks = scene.masks ?? [];
  if (!Array.isArray(masks) || masks.length > 4) throw new RangeError("At most four independent masks are supported.");
  const maskSlots = /* @__PURE__ */ new Map();
  const maskCoreThresholds = new Float32Array(4);
  for (const [slot, mask] of masks.entries()) {
    if (typeof mask?.id !== "string" || !mask.id || maskSlots.has(mask.id) || !Array.isArray(mask.parts)) {
      throw new TypeError("Each mask requires a unique id and a parts array.");
    }
    maskSlots.set(mask.id, slot);
    if (mask.coreThreshold !== void 0) {
      const threshold = finiteNumber(mask.coreThreshold, mask.id + ".coreThreshold");
      if (threshold <= 0 || threshold > 1) throw new RangeError("mask.coreThreshold must be in (0,1].");
      maskCoreThresholds[slot] = threshold;
    }
    if (mask.supportThreshold !== void 0) {
      if (mask.coreThreshold !== void 0) throw new RangeError("A mask cannot specify both coreThreshold and supportThreshold.");
      const threshold = finiteNumber(mask.supportThreshold, mask.id + ".supportThreshold");
      if (threshold <= 0 || threshold > 1) throw new RangeError("supportThreshold must be in (0,1].");
      maskCoreThresholds[slot] = -threshold;
    }
  }
  const parseClip = (value) => {
    if (value == null || value === false) return null;
    if (typeof value === "string") value = { mask: value };
    const slot = maskSlots.get(value.mask);
    if (slot === void 0) throw new RangeError("Unknown mask: " + value.mask);
    const mode = value.mode ?? "inside";
    if (mode !== "inside" && mode !== "outside") throw new RangeError("clip.mode must be inside or outside.");
    return {
      mask: value.mask,
      slot,
      outside: mode === "outside" ? 1 : 0,
      strength: clamp01(finiteNumber(value.strength ?? 1, "clip.strength"))
    };
  };
  const parseIndices = (value, count, label) => {
    if (!Array.isArray(value) && !ArrayBuffer.isView(value) || !value.length || value.length % 3) {
      throw new TypeError(label + " must contain complete triangles.");
    }
    for (const index of value) if (!Number.isInteger(index) || index < 0 || index >= count) {
      throw new RangeError(label + " contains an out-of-range vertex.");
    }
    return new Uint16Array(value);
  };
  const parts = [], byId = /* @__PURE__ */ new Map();
  let vertexCount = 0, maskVertexCount = 0;
  for (const input of scene.parts) {
    if (typeof input?.id !== "string" || !input.id || byId.has(input.id)) throw new TypeError("Parts require unique string ids.");
    const xy = numericArray(input.xy, null, input.id + ".xy");
    if (xy.length < 6 || xy.length % 2) throw new RangeError(input.id + ".xy must contain at least three 2D vertices.");
    const count = xy.length / 2;
    if (vertexCount + count > LIMIT_VERTICES) throw new RangeError("The scene exceeds the portable 65535-vertex budget.");
    const page = input.page ?? 0;
    if (page !== 0 && page !== 1) throw new RangeError("part.page must be 0 or 1.");
    const part = {
      id: input.id,
      count,
      base: vertexCount,
      ordinal: parts.length,
      xy,
      uv: numericArray(input.uv, xy.length, input.id + ".uv"),
      uv2: input.uv2 == null ? null : numericArray(input.uv2, xy.length, input.id + ".uv2"),
      mix: scalarOrArray(input.mix ?? 0, count, input.id + ".mix"),
      rootUV: input.rootUV == null ? null : numericArray(input.rootUV, xy.length, input.id + ".rootUV"),
      rootUV2: input.rootUV2 == null ? null : numericArray(input.rootUV2, xy.length, input.id + ".rootUV2"),
      rootMix: scalarOrArray(input.rootMix ?? 0, count, input.id + ".rootMix"),
      rootWeight: scalarOrArray(input.rootWeight ?? 0, count, input.id + ".rootWeight"),
      vertexAlpha: input.vertexAlpha == null ? null : numericArray(input.vertexAlpha, count, input.id + ".vertexAlpha"),
      alpha: clamp01(finiteNumber(input.alpha ?? 1, input.id + ".alpha")),
      page,
      z: finiteNumber(input.z ?? 0, input.id + ".z"),
      visible: input.visible !== false,
      maskOnly: input.maskOnly === true,
      clip: parseClip(input.clip),
      indices: parseIndices(input.indices, count, input.id + ".indices"),
      maskBits: 0,
      coreMaskBits: 0,
      maskBase: 0
    };
    vertexCount += count;
    parts.push(part);
    byId.set(part.id, part);
  }
  for (const [slot, mask] of masks.entries()) for (const id of new Set(mask.parts)) {
    const part = byId.get(id);
    if (!part) throw new RangeError("Unknown mask source: " + id);
    if (maskCoreThresholds[slot]) {
      if (part.maskOnly || part.clip) throw new RangeError("Core mask source must be an unclipped color part: " + id);
      part.coreMaskBits |= 1 << slot;
    }
    part.maskBits |= 1 << slot;
  }
  for (const part of parts) if (part.maskBits) {
    part.maskBase = maskVertexCount;
    maskVertexCount += part.count;
  }
  const vertexData = new Float32Array(vertexCount * STRIDE);
  const maskVertexData = new Float32Array(maskVertexCount * STRIDE);
  let ordered = parts.slice(), orderDirty = true, topologyDirty = true;
  let indexData = new Uint16Array(0), maskIndexData = new Uint16Array(0);
  let previousMain = [], previousMask = [], indexVersion = 0, maskIndexVersion = 0;
  let preparations = 0;
  const activeMain = [], activeMask = [], invalidParts = [];
  const bounds = [0, 0, 0, 0];
  function updatePart(id, patch) {
    const part = byId.get(id);
    if (!part) throw new RangeError("Unknown part: " + id);
    if (!patch || typeof patch !== "object") throw new TypeError("Part patch must be an object.");
    const next = {};
    for (const name of ["xy", "uv"]) if (own(patch, name)) next[name] = numericArray(patch[name], part.count * 2, id + "." + name);
    for (const name of ["uv2", "rootUV", "rootUV2"]) if (own(patch, name)) {
      next[name] = patch[name] == null ? null : numericArray(patch[name], part.count * 2, id + "." + name);
    }
    if (own(patch, "vertexAlpha")) next.vertexAlpha = patch.vertexAlpha == null ? null : numericArray(patch.vertexAlpha, part.count, id + ".vertexAlpha");
    for (const name of ["mix", "rootMix", "rootWeight"]) if (own(patch, name)) {
      next[name] = scalarOrArray(patch[name], part.count, id + "." + name);
    }
    if (own(patch, "alpha")) next.alpha = clamp01(finiteNumber(patch.alpha, id + ".alpha"));
    if (own(patch, "z")) next.z = finiteNumber(patch.z, id + ".z");
    if (own(patch, "page")) {
      if (patch.page !== 0 && patch.page !== 1) throw new RangeError("part.page must be 0 or 1.");
      next.page = patch.page;
    }
    if (own(patch, "visible")) next.visible = patch.visible !== false;
    if (own(patch, "maskOnly")) next.maskOnly = patch.maskOnly === true;
    if (own(patch, "clip")) next.clip = parseClip(patch.clip);
    if (own(patch, "indices")) next.indices = parseIndices(patch.indices, part.count, id + ".indices");
    if (part.coreMaskBits && ((next.maskOnly ?? part.maskOnly) || (own(next, "clip") ? next.clip : part.clip))) {
      throw new RangeError("Core mask source must remain an unclipped color part: " + id);
    }
    if (own(next, "z") && next.z !== part.z) orderDirty = true;
    if (own(next, "indices")) topologyDirty = true;
    Object.assign(part, next);
    return api;
  }
  const sameParts = (a, b) => a.length === b.length && a.every((part, i) => part === b[i]);
  function indicesFor(list, baseName) {
    const out = new Uint16Array(list.reduce((count, part) => count + part.indices.length, 0));
    let at = 0;
    for (const part of list) for (const index of part.indices) out[at++] = part[baseName] + index;
    return out;
  }
  function prepare() {
    if (orderDirty) {
      ordered = parts.slice().sort((a, b) => a.z - b.z || a.ordinal - b.ordinal);
      orderDirty = false;
    }
    activeMain.length = 0;
    activeMask.length = 0;
    invalidParts.length = 0;
    let left = Infinity, top = Infinity, right = -Infinity, bottom = -Infinity;
    let needsMasks = false, writtenVertices = 0;
    for (const part of ordered) {
      if (!part.visible || part.alpha <= 1e-3 || part.maskOnly && !part.maskBits) continue;
      const uv2 = part.uv2 ?? part.uv;
      const rootUV = part.rootUV ?? part.uv, rootUV2 = part.rootUV2 ?? rootUV;
      let valid = true, minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
      for (let i = 0; i < part.count; i++) {
        const j = i * 2, at = (part.base + i) * STRIDE;
        const x = part.xy[j], y = part.xy[j + 1], u = part.uv[j], v = part.uv[j + 1], u2 = uv2[j], v2 = uv2[j + 1];
        const mix2 = typeof part.mix === "number" ? part.mix : part.mix[i];
        const ru = rootUV[j], rv = rootUV[j + 1], ru2 = rootUV2[j], rv2 = rootUV2[j + 1];
        const rootMix = typeof part.rootMix === "number" ? part.rootMix : part.rootMix[i];
        const rootWeight = typeof part.rootWeight === "number" ? part.rootWeight : part.rootWeight[i];
        const alpha = part.alpha * (part.vertexAlpha ? part.vertexAlpha[i] : 1);
        if (!Number.isFinite(x + y + u + v + u2 + v2 + mix2 + alpha + ru + rv + ru2 + rv2 + rootMix + rootWeight)) {
          valid = false;
          break;
        }
        vertexData[at] = x;
        vertexData[at + 1] = y;
        vertexData[at + 2] = u;
        vertexData[at + 3] = v;
        vertexData[at + 4] = u2;
        vertexData[at + 5] = v2;
        vertexData[at + 6] = clamp01(alpha);
        vertexData[at + 7] = part.page;
        vertexData[at + 8] = clamp01(mix2);
        vertexData[at + 9] = part.clip?.outside ?? 0;
        for (let k = 0; k < 4; k++) vertexData[at + 10 + k] = part.clip?.slot === k ? part.clip.strength : 0;
        vertexData[at + 14] = ru;
        vertexData[at + 15] = rv;
        vertexData[at + 16] = ru2;
        vertexData[at + 17] = rv2;
        vertexData[at + 18] = clamp01(rootMix);
        vertexData[at + 19] = clamp01(rootWeight);
        if (part.maskBits) {
          const mt = (part.maskBase + i) * STRIDE;
          for (let k = 0; k < 9; k++) maskVertexData[mt + k] = vertexData[at + k];
          maskVertexData[mt + 9] = 0;
          for (let k = 0; k < 4; k++) maskVertexData[mt + 10 + k] = part.maskBits >> k & 1;
        }
        minX = Math.min(minX, x);
        minY = Math.min(minY, y);
        maxX = Math.max(maxX, x);
        maxY = Math.max(maxY, y);
      }
      if (!valid) {
        invalidParts.push(part.id);
        continue;
      }
      writtenVertices += part.count;
      if (part.maskBits) activeMask.push(part);
      if (!part.maskOnly) {
        activeMain.push(part);
        needsMasks ||= !!part.clip?.strength;
        left = Math.min(left, minX);
        top = Math.min(top, minY);
        right = Math.max(right, maxX);
        bottom = Math.max(bottom, maxY);
      }
    }
    if (topologyDirty || !sameParts(activeMain, previousMain)) {
      indexData = indicesFor(activeMain, "base");
      previousMain = activeMain.slice();
      indexVersion++;
    }
    if (topologyDirty || !sameParts(activeMask, previousMask)) {
      maskIndexData = indicesFor(activeMask, "maskBase");
      previousMask = activeMask.slice();
      maskIndexVersion++;
    }
    topologyDirty = false;
    preparations++;
    bounds[0] = left;
    bounds[1] = top;
    bounds[2] = right;
    bounds[3] = bottom;
    return {
      vertexData,
      maskVertexData,
      indexData,
      maskIndexData,
      indexVersion,
      maskIndexVersion,
      maskCoreThresholds,
      needsMasks,
      bounds: activeMain.length ? bounds : null,
      invalidParts,
      visibleParts: activeMain.length,
      maskParts: activeMask.length,
      writtenVertices
    };
  }
  const api = {
    updatePart,
    prepare,
    inspect: () => ({
      parts: parts.length,
      vertices: vertexCount,
      maskVertices: maskVertexCount,
      masks: masks.map((mask) => mask.id),
      strideFloats: STRIDE,
      preparations,
      coreThresholds: Array.from(maskCoreThresholds),
      mainOrder: previousMain.map((part) => part.id),
      maskSources: previousMask.map((part) => part.id)
    })
  };
  return api;
}
var MESH_VERTEX = `
precision highp float;
attribute vec2 aPosition;
attribute vec4 aUV;
attribute vec4 aStyle;
attribute vec4 aMask;
attribute vec4 aRootUV;
attribute vec2 aRootStyle;
uniform vec4 uView;
varying vec4 vUV;
varying vec4 vStyle;
varying vec4 vMask;
varying vec4 vRootUV;
varying vec2 vRootStyle;
void main() {
  vec2 p = (aPosition - uView.xy) * uView.zw;
  gl_Position = vec4(p.x * 2.0 - 1.0, 1.0 - p.y * 2.0, 0.0, 1.0);
  vUV = aUV; vStyle = aStyle; vMask = aMask;
  vRootUV = aRootUV; vRootStyle = aRootStyle;
}`;
var SAMPLE_ART = `
uniform sampler2D uAtlas;
uniform sampler2D uExpression;
varying vec4 vUV;
varying vec4 vStyle;
varying vec4 vMask;
vec4 artwork(vec2 uv) {
  if (vStyle.y < 0.5) return texture2D(uAtlas, uv);
  return texture2D(uExpression, uv);
}
vec4 surface() {
  vec4 color = artwork(vUV.xy);
  if (vStyle.z > 0.00001) color = mix(color, artwork(vUV.zw), vStyle.z);
  return color * vStyle.x;
}`;
var MAIN_FRAGMENT = SAMPLE_ART + `
varying vec4 vRootUV;
varying vec2 vRootStyle;
uniform sampler2D uMasks;
uniform vec2 uPixelInv;
uniform vec4 uCoreThresholds;
void main() {
  vec4 color = surface();
  if (vRootStyle.y > 0.00001 && color.a > 0.0) {
    vec4 root = artwork(vRootUV.xy);
    if (vRootStyle.x > 0.00001) root = mix(root, artwork(vRootUV.zw), vRootStyle.x);
    // Reconstruct the shared material's RGB, preserving the original coverage.
    // An empty source texel is not a black material: retain the original color.
    if (root.a > 0.00001) color.rgb = mix(color.rgb, root.rgb / root.a * color.a, vRootStyle.y);
  }
  float strength = dot(vMask, vec4(1.0));
  if (strength > 0.00001) {
    float coverage = dot(texture2D(uMasks, gl_FragCoord.xy * uPixelInv), vMask) / strength;
    // Threshold after channel union, never each source separately: overlapping
    // translucent color sources can legitimately form a fully opaque core.
    float core = dot(uCoreThresholds, vMask) / strength;
    if (core < 0.0) {
      coverage = smoothstep(0.0, -core, coverage);
    } else if (core > 0.0) {
      if (core >= 1.0) coverage = step(1.0, coverage);
      else coverage = smoothstep(core, 1.0, coverage);
    }
    if (vStyle.w > 0.5) coverage = 1.0 - coverage;
    color *= mix(1.0, coverage, strength);
  }
  gl_FragColor = color;
}`;
var MASK_FRAGMENT = SAMPLE_ART + `
void main() { gl_FragColor = vMask * surface().a; }
`;
var QUAD_VERTEX = `
precision highp float;
attribute vec2 aPosition;
varying vec2 vUV;
void main() { gl_Position = vec4(aPosition, 0.0, 1.0); vUV = aPosition * 0.5 + 0.5; }
`;
var OUTLINE_FRAGMENT = `
uniform sampler2D uColor;
uniform vec2 uStep;
uniform vec4 uOutline;
varying vec2 vUV;
void main() {
  vec4 base = texture2D(uColor, vUV);
  if (base.a == 1.0) { gl_FragColor = base; return; }
  float a = base.a;
  a = max(a, texture2D(uColor, vUV + vec2(uStep.x, 0.0)).a);
  a = max(a, texture2D(uColor, vUV - vec2(uStep.x, 0.0)).a);
  a = max(a, texture2D(uColor, vUV + vec2(0.0, uStep.y)).a);
  a = max(a, texture2D(uColor, vUV - vec2(0.0, uStep.y)).a);
  vec2 d = uStep * 0.70710678118;
  a = max(a, texture2D(uColor, vUV + d).a);
  a = max(a, texture2D(uColor, vUV - d).a);
  a = max(a, texture2D(uColor, vUV + vec2(d.x, -d.y)).a);
  a = max(a, texture2D(uColor, vUV + vec2(-d.x, d.y)).a);
  // Stroke only newly covered alpha. A uniformly translucent interior must
  // not acquire the outline color merely because its base alpha is below one.
  float edge = max(0.0, a - base.a) * uOutline.a;
  gl_FragColor = base + vec4(uOutline.rgb * edge, edge);
}`;
function createAtlasRenderer(canvas, options = {}) {
  if (!canvas?.getContext || !canvas?.addEventListener) throw new TypeError("A canvas with WebGL context events is required.");
  let view = normalizeView(options.view ?? [0, 0, 1, 1]);
  let maxEdge = options.maxEdge ?? 512;
  fitBackingSize(1, 1, maxEdge);
  let outline = normalizeOutline(options.outline);
  const attributes = {
    alpha: true,
    premultipliedAlpha: true,
    antialias: false,
    depth: false,
    stencil: false,
    preserveDrawingBuffer: options.preserveDrawingBuffer === true,
    powerPreference: options.powerPreference ?? "high-performance"
  };
  let gl = null, gl2 = false;
  if (options.webgl !== 1) {
    gl = canvas.getContext("webgl2", attributes);
    gl2 = !!gl;
  }
  if (!gl) gl = canvas.getContext("webgl", attributes);
  if (!gl) throw new Error("WebGL is unavailable; the atlas renderer could not be created.");
  let batch = createAtlasBatch();
  let resources = null, disposed = false, lost = false, width = 0, height = 0;
  let requestedWidth = canvas.width || 1, requestedHeight = canvas.height || 1;
  let currentIndexVersion = -1, currentMaskIndexVersion = -1;
  const uploads = [{ source: null, version: null }, { source: null, version: null }];
  const invalidReported = /* @__PURE__ */ new Set();
  const stats = {
    frames: 0,
    contextLosses: 0,
    contextRestores: 0,
    resourceBuilds: 0,
    resizes: 0,
    atlasUploads: 0,
    expressionUploads: 0,
    textureUploadBytes: 0,
    bufferUploadBytes: 0,
    lastBufferUploadBytes: 0,
    lastCpuMilliseconds: 0,
    lastPackMilliseconds: 0,
    lastDrawCalls: { mask: 0, main: 0, outline: 0, total: 0 },
    lastVisibleParts: 0,
    lastInvalidParts: [],
    lastBounds: null,
    lastPostRectangle: null,
    lastError: null,
    errors: [],
    capabilities: null
  };
  function notify(callback, value) {
    if (typeof callback !== "function") return;
    try {
      callback(value);
    } catch (error) {
      stats.lastError = "Renderer callback: " + error.message;
    }
  }
  function reportError(error) {
    const message = String(error?.message ?? error);
    stats.lastError = message;
    stats.errors.push(message);
    if (stats.errors.length > 12) stats.errors.shift();
    notify(options.onError, error instanceof Error ? error : new Error(message));
  }
  function assertUsable() {
    if (disposed) throw new Error("The atlas renderer is disposed.");
  }
  function shaderSource(source, fragment, highPrecision) {
    let result = (fragment ? `precision ${highPrecision ? "highp" : "mediump"} float;
` : "") + source;
    result = result.replace(/\bvarying\s+/g, `varying ${highPrecision ? "highp" : "mediump"} `);
    if (gl2) {
      result = result.replace(/\battribute\b/g, "in").replace(/\bvarying\b/g, fragment ? "in" : "out").replace(/\btexture2D\b/g, "texture").replace(/\bgl_FragColor\b/g, "fragmentColor");
      result = "#version 300 es\n" + (fragment ? "out highp vec4 fragmentColor;\n" : "") + result;
    }
    return result;
  }
  function program(vertex, fragment, highPrecision) {
    const shaders = [], object = gl.createProgram();
    if (!object) throw new Error("Could not allocate a WebGL program.");
    try {
      for (const [type, source] of [
        [gl.VERTEX_SHADER, shaderSource(vertex, false, highPrecision)],
        [gl.FRAGMENT_SHADER, shaderSource(fragment, true, highPrecision)]
      ]) {
        const shader = gl.createShader(type);
        if (!shader) throw new Error("Could not allocate a WebGL shader.");
        shaders.push(shader);
        gl.shaderSource(shader, source);
        gl.compileShader(shader);
        if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) throw new Error("Shader compilation: " + gl.getShaderInfoLog(shader));
        gl.attachShader(object, shader);
      }
      for (const [index, name] of ["aPosition", "aUV", "aStyle", "aMask", "aRootUV", "aRootStyle"].entries()) {
        gl.bindAttribLocation(object, index, name);
      }
      gl.linkProgram(object);
      if (!gl.getProgramParameter(object, gl.LINK_STATUS)) throw new Error("Shader link: " + gl.getProgramInfoLog(object));
      const uniforms = {};
      for (const name of ["uView", "uAtlas", "uExpression", "uMasks", "uPixelInv", "uCoreThresholds", "uColor", "uStep", "uOutline"]) {
        uniforms[name] = gl.getUniformLocation(object, name);
      }
      return { object, uniforms };
    } catch (error) {
      gl.deleteProgram(object);
      throw error;
    } finally {
      for (const shader of shaders) gl.deleteShader(shader);
    }
  }
  function newTexture() {
    const texture = gl.createTexture();
    if (!texture) throw new Error("Could not allocate a texture.");
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array(4));
    return { texture, width: 1, height: 1 };
  }
  function newBuffer() {
    const object = gl.createBuffer();
    if (!object) throw new Error("Could not allocate a buffer.");
    return { object, capacity: 0 };
  }
  function target() {
    const image = newTexture(), framebuffer = gl.createFramebuffer();
    if (!framebuffer) {
      gl.deleteTexture(image.texture);
      throw new Error("Could not allocate a framebuffer.");
    }
    return { ...image, framebuffer };
  }
  function destroyResources() {
    const r = resources;
    resources = null;
    if (!r || lost) return;
    for (const p of [r.main, r.mask, r.post]) if (p) gl.deleteProgram(p.object);
    for (const b of [r.vertices, r.elements, r.maskVertices, r.maskElements, r.quad]) if (b) gl.deleteBuffer(b.object);
    for (const t of [...r.atlases, r.colorTarget, r.maskTarget]) if (t) {
      gl.deleteTexture(t.texture);
      if (t.framebuffer) gl.deleteFramebuffer(t.framebuffer);
    }
  }
  function buildResources() {
    const highPrecision = gl2 || !!gl.getShaderPrecisionFormat(gl.FRAGMENT_SHADER, gl.HIGH_FLOAT)?.precision;
    stats.capabilities = {
      webgl: gl2 ? 2 : 1,
      fragmentHighPrecision: highPrecision,
      maxTextureSize: gl.getParameter(gl.MAX_TEXTURE_SIZE),
      maxTextureUnits: gl.getParameter(gl.MAX_TEXTURE_IMAGE_UNITS),
      contextAttributes: gl.getContextAttributes()
    };
    if (stats.capabilities.maxTextureUnits < 3) throw new Error("Three fragment texture units are required.");
    const r = resources = { atlases: [] };
    try {
      r.main = program(MESH_VERTEX, MAIN_FRAGMENT, highPrecision);
      r.mask = program(MESH_VERTEX, MASK_FRAGMENT, highPrecision);
      r.post = program(QUAD_VERTEX, OUTLINE_FRAGMENT, highPrecision);
      r.vertices = newBuffer();
      r.elements = newBuffer();
      r.maskVertices = newBuffer();
      r.maskElements = newBuffer();
      r.quad = newBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, r.quad.object);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
      r.quad.capacity = 24;
      r.atlases.push(newTexture());
      r.atlases.push(newTexture());
      r.colorTarget = target();
      r.maskTarget = target();
      currentIndexVersion = -1;
      currentMaskIndexVersion = -1;
      stats.resourceBuilds++;
      resizeTargets(true);
      for (let page = 0; page < 2; page++) if (uploads[page].source) upload(page, uploads[page].source, uploads[page].version, true);
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    } catch (error) {
      destroyResources();
      throw error;
    }
  }
  function resizeTargets(force = false) {
    if (!resources || lost) return;
    for (const t of [resources.colorTarget, resources.maskTarget]) {
      if (!force && t.width === width && t.height === height) continue;
      gl.bindTexture(gl.TEXTURE_2D, t.texture);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, width, height, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
      t.width = width;
      t.height = height;
      gl.bindFramebuffer(gl.FRAMEBUFFER, t.framebuffer);
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, t.texture, 0);
      if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE) throw new Error("The render target is incomplete.");
    }
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  }
  function sourceSize(source) {
    if (Object.prototype.toString.call(source) === "[object ImageBitmap]") {
      throw new TypeError("Copy ImageBitmap into a 2D canvas before atlas upload.");
    }
    const w = source?.naturalWidth ?? source?.width, h = source?.naturalHeight ?? source?.height;
    if (!Number.isInteger(w) || !Number.isInteger(h) || w < 1 || h < 1) throw new TypeError("Atlas image/canvas must be decoded and nonempty.");
    if (w > stats.capabilities.maxTextureSize || h > stats.capabilities.maxTextureSize) throw new RangeError("Atlas exceeds MAX_TEXTURE_SIZE.");
    return [w, h];
  }
  function upload(page, source, version, force = false) {
    assertUsable();
    const [w, h] = sourceSize(source), prior = uploads[page];
    if (!force && version !== void 0 && prior.source === source && prior.version === version) return false;
    uploads[page] = { source, version };
    if (lost || !resources) return false;
    const t = resources.atlases[page];
    try {
      gl.activeTexture(gl.TEXTURE0 + page);
      gl.bindTexture(gl.TEXTURE_2D, t.texture);
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
      gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, true);
      gl.pixelStorei(gl.UNPACK_COLORSPACE_CONVERSION_WEBGL, gl.NONE);
      if (t.width === w && t.height === h) gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, gl.RGBA, gl.UNSIGNED_BYTE, source);
      else {
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, source);
        t.width = w;
        t.height = h;
      }
      if (page) stats.expressionUploads++;
      else stats.atlasUploads++;
      stats.textureUploadBytes += w * h * 4;
      return true;
    } catch (error) {
      uploads[page] = prior;
      reportError(error);
      throw error;
    }
  }
  function resize(w, h, settings = {}) {
    assertUsable();
    const nextEdge = settings.maxEdge ?? maxEdge;
    const [nextW, nextH] = fitBackingSize(w, h, nextEdge);
    requestedWidth = w;
    requestedHeight = h;
    maxEdge = nextEdge;
    if (nextW === width && nextH === height) return false;
    width = nextW;
    height = nextH;
    canvas.width = width;
    canvas.height = height;
    stats.resizes++;
    if (resources && !lost) resizeTargets();
    return true;
  }
  function bufferUpload(targetType, buffer, data) {
    gl.bindBuffer(targetType, buffer.object);
    if (!data.byteLength) return;
    if (buffer.capacity < data.byteLength) {
      buffer.capacity = 2 ** Math.ceil(Math.log2(Math.max(256, data.byteLength)));
      gl.bufferData(targetType, buffer.capacity, gl.DYNAMIC_DRAW);
    }
    gl.bufferSubData(targetType, 0, data);
    stats.lastBufferUploadBytes += data.byteLength;
    stats.bufferUploadBytes += data.byteLength;
  }
  function meshAttributes(vertexBuffer, elementBuffer) {
    gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer.object);
    for (const [index, size, offset] of [[0, 2, 0], [1, 4, 2], [2, 4, 6], [3, 4, 10], [4, 4, 14], [5, 2, 18]]) {
      gl.enableVertexAttribArray(index);
      gl.vertexAttribPointer(index, size, gl.FLOAT, false, STRIDE_BYTES, offset * 4);
    }
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, elementBuffer.object);
  }
  function useMesh(programInfo) {
    gl.useProgram(programInfo.object);
    const u = programInfo.uniforms;
    gl.uniform4f(u.uView, view[0], view[1], 1 / (view[2] - view[0]), 1 / (view[3] - view[1]));
    gl.uniform1i(u.uAtlas, 0);
    gl.uniform1i(u.uExpression, 1);
  }
  function clearTarget(framebuffer) {
    gl.bindFramebuffer(gl.FRAMEBUFFER, framebuffer);
    gl.viewport(0, 0, width, height);
    gl.disable(gl.SCISSOR_TEST);
    gl.colorMask(true, true, true, true);
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT);
  }
  function postRectangle(bounds) {
    if (!bounds) return [0, 0, 0, 0];
    const sx = width / (view[2] - view[0]), sy = height / (view[3] - view[1]);
    const padX = Math.ceil(outline.width * sx) + 2, padY = Math.ceil(outline.width * sy) + 2;
    const x0 = Math.max(0, Math.floor((bounds[0] - view[0]) * sx) - padX);
    const x1 = Math.min(width, Math.ceil((bounds[2] - view[0]) * sx) + padX);
    const y0 = Math.max(0, Math.floor((view[3] - bounds[3]) * sy) - padY);
    const y1 = Math.min(height, Math.ceil((view[3] - bounds[1]) * sy) + padY);
    return [Math.min(width, x0), Math.min(height, y0), Math.max(0, x1 - x0), Math.max(0, y1 - y0)];
  }
  function render() {
    assertUsable();
    if (lost || !resources || !uploads[0].source) return false;
    const began = clock();
    const calls = stats.lastDrawCalls = { mask: 0, main: 0, outline: 0, total: 0 };
    stats.lastBufferUploadBytes = 0;
    try {
      const prepared = batch.prepare();
      stats.lastPackMilliseconds = clock() - began;
      stats.lastVisibleParts = prepared.visibleParts;
      stats.lastInvalidParts = prepared.invalidParts.slice();
      stats.lastBounds = prepared.bounds ? prepared.bounds.slice() : null;
      for (const id of prepared.invalidParts) if (!invalidReported.has(id)) {
        invalidReported.add(id);
        reportError(new Error("Non-finite vertex data; skipped part: " + id));
      }
      for (const id of invalidReported) if (!prepared.invalidParts.includes(id)) invalidReported.delete(id);
      const r = resources;
      gl.disable(gl.DEPTH_TEST);
      gl.disable(gl.STENCIL_TEST);
      gl.disable(gl.CULL_FACE);
      gl.blendEquation(gl.FUNC_ADD);
      for (let page = 0; page < 2; page++) {
        gl.activeTexture(gl.TEXTURE0 + page);
        gl.bindTexture(gl.TEXTURE_2D, r.atlases[page].texture);
      }
      if (prepared.needsMasks) {
        gl.activeTexture(gl.TEXTURE2);
        gl.bindTexture(gl.TEXTURE_2D, null);
        clearTarget(r.maskTarget.framebuffer);
        if (prepared.maskIndexData.length) {
          bufferUpload(gl.ARRAY_BUFFER, r.maskVertices, prepared.maskVertexData);
          if (prepared.maskIndexVersion !== currentMaskIndexVersion) {
            bufferUpload(gl.ELEMENT_ARRAY_BUFFER, r.maskElements, prepared.maskIndexData);
            currentMaskIndexVersion = prepared.maskIndexVersion;
          }
          useMesh(r.mask);
          meshAttributes(r.maskVertices, r.maskElements);
          gl.enable(gl.BLEND);
          gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_COLOR);
          gl.drawElements(gl.TRIANGLES, prepared.maskIndexData.length, gl.UNSIGNED_SHORT, 0);
          calls.mask = 1;
        }
      }
      clearTarget(outline.enabled ? r.colorTarget.framebuffer : null);
      if (prepared.indexData.length) {
        bufferUpload(gl.ARRAY_BUFFER, r.vertices, prepared.vertexData);
        if (prepared.indexVersion !== currentIndexVersion) {
          bufferUpload(gl.ELEMENT_ARRAY_BUFFER, r.elements, prepared.indexData);
          currentIndexVersion = prepared.indexVersion;
        }
        useMesh(r.main);
        meshAttributes(r.vertices, r.elements);
        gl.activeTexture(gl.TEXTURE2);
        gl.bindTexture(gl.TEXTURE_2D, r.maskTarget.texture);
        gl.uniform1i(r.main.uniforms.uMasks, 2);
        gl.uniform2f(r.main.uniforms.uPixelInv, 1 / width, 1 / height);
        gl.uniform4fv(r.main.uniforms.uCoreThresholds, prepared.maskCoreThresholds);
        gl.enable(gl.BLEND);
        gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
        gl.drawElements(gl.TRIANGLES, prepared.indexData.length, gl.UNSIGNED_SHORT, 0);
        calls.main = 1;
      }
      if (outline.enabled) {
        clearTarget(null);
        const rectangle = postRectangle(prepared.bounds);
        stats.lastPostRectangle = rectangle;
        if (rectangle[2] && rectangle[3]) {
          gl.enable(gl.SCISSOR_TEST);
          gl.scissor(...rectangle);
          gl.disable(gl.BLEND);
          gl.useProgram(r.post.object);
          gl.activeTexture(gl.TEXTURE0);
          gl.bindTexture(gl.TEXTURE_2D, r.colorTarget.texture);
          gl.uniform1i(r.post.uniforms.uColor, 0);
          gl.uniform2f(r.post.uniforms.uStep, outline.width / (view[2] - view[0]), outline.width / (view[3] - view[1]));
          gl.uniform4fv(r.post.uniforms.uOutline, outline.color);
          gl.bindBuffer(gl.ARRAY_BUFFER, r.quad.object);
          gl.enableVertexAttribArray(0);
          gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
          for (let i = 1; i < 6; i++) gl.disableVertexAttribArray(i);
          gl.drawArrays(gl.TRIANGLES, 0, 3);
          calls.outline = 1;
        }
      } else stats.lastPostRectangle = null;
      stats.frames++;
      return true;
    } catch (error) {
      reportError(error);
      return false;
    } finally {
      calls.total = calls.mask + calls.main + calls.outline;
      stats.lastCpuMilliseconds = clock() - began;
      gl.disable(gl.SCISSOR_TEST);
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    }
  }
  function inspect() {
    return {
      ...stats,
      lastDrawCalls: { ...stats.lastDrawCalls },
      errors: stats.errors.slice(),
      capabilities: stats.capabilities ? {
        ...stats.capabilities,
        contextAttributes: { ...stats.capabilities.contextAttributes }
      } : null,
      lastInvalidParts: stats.lastInvalidParts.slice(),
      lastBounds: stats.lastBounds?.slice() ?? null,
      lastPostRectangle: stats.lastPostRectangle?.slice() ?? null,
      ready: !disposed && !lost && !!resources && !!uploads[0].source,
      disposed,
      contextLost: lost,
      width,
      height,
      maxEdge,
      view: view.slice(),
      outline: { ...outline, color: outline.color.slice(), taps: 8 },
      batch: batch.inspect(),
      atlases: uploads.map((record, page) => ({
        page,
        present: !!record.source,
        version: record.version,
        width: resources?.atlases[page]?.width ?? 0,
        height: resources?.atlases[page]?.height ?? 0
      })),
      timingNote: "Synchronous CPU packing/submission wall time; not isolated GPU time or a frame-rate guarantee."
    };
  }
  function onLost(event) {
    event.preventDefault();
    lost = true;
    resources = null;
    stats.contextLosses++;
    notify(options.onContextLost, { message: "WebGL context lost. Retained atlas sources will be re-uploaded on restoration." });
  }
  function onRestored() {
    if (disposed) return;
    lost = false;
    try {
      buildResources();
      stats.contextRestores++;
      notify(options.onContextRestored, inspect());
    } catch (error) {
      reportError(error);
    }
  }
  function dispose() {
    if (disposed) return;
    canvas.removeEventListener("webglcontextlost", onLost);
    canvas.removeEventListener("webglcontextrestored", onRestored);
    destroyResources();
    disposed = true;
    uploads[0].source = null;
    uploads[1].source = null;
  }
  canvas.addEventListener("webglcontextlost", onLost);
  canvas.addEventListener("webglcontextrestored", onRestored);
  try {
    resize(requestedWidth, requestedHeight);
    buildResources();
  } catch (error) {
    canvas.removeEventListener("webglcontextlost", onLost);
    canvas.removeEventListener("webglcontextrestored", onRestored);
    destroyResources();
    throw error;
  }
  const api = {
    setAtlas(source, settings = {}) {
      return upload(0, source, settings.version);
    },
    setExpressionAtlas(source, settings = {}) {
      return upload(1, source, settings.version);
    },
    setScene(scene) {
      assertUsable();
      const next = createAtlasBatch(scene);
      batch = next;
      currentIndexVersion = -1;
      currentMaskIndexVersion = -1;
      invalidReported.clear();
      return api;
    },
    updatePart(id, patch) {
      assertUsable();
      batch.updatePart(id, patch);
      return api;
    },
    setView(value) {
      assertUsable();
      view = normalizeView(value);
      return api;
    },
    setOutline(value) {
      assertUsable();
      outline = normalizeOutline(value);
      return api;
    },
    resize,
    render,
    inspect,
    dispose
  };
  return api;
}

// runtime/animation.js
var clamp2 = (value, lo, hi) => Math.min(hi, Math.max(lo, value));
var finite = (value, fallback = 0) => Number.isFinite(value) ? value : fallback;
var unit = (value) => clamp2(finite(value), 0, 1);
var TAU = Math.PI * 2;
var smooth = (value) => {
  const x = unit(value);
  return x * x * (3 - 2 * x);
};
var envelope = (k, rise = 0.2, release = 0.8) => smooth(k / rise) * (1 - smooth((k - release) / (1 - release)));
var bell = (value) => value <= 0 || value >= 1 ? 0 : Math.sin(Math.PI * value) ** 2;
var mix = (a, b, k) => a + (b - a) * k;
var SHAPES = ["smile", "open", "o", "sad"];
var oneMouth = (shape) => Object.fromEntries(SHAPES.map((key) => [key, key === shape ? 1 : 0]));
var BASE = Object.freeze({
  eyeL: 1,
  eyeR: 1,
  happyL: 0,
  happyR: 0,
  eyeTiltL: 0,
  eyeTiltR: 0,
  browY: 0,
  browTilt: 0,
  mouthW: 9,
  mouthH: 2.4,
  blush: 0,
  tear: 0,
  headTilt: 0,
  headY: 0,
  bodyY: 0,
  bodySX: 1,
  bodySY: 1,
  bodyTilt: 0,
  armL: 0,
  armR: 0,
  handIn: 0,
  earLiftL: 0,
  earLiftR: 0,
  earRaiseL: 0,
  earRaiseR: 0,
  earSpreadL: 0,
  earSpreadR: 0,
  earInL: 0,
  earInR: 0,
  earCurlL: 0,
  earCurlR: 0,
  earTipL: 0,
  earTipR: 0,
  footLiftL: 0,
  footLiftR: 0,
  footXL: 0,
  footXR: 0,
  tail: 0,
  yawOffset: 0
});
var LIMITS = Object.freeze({
  eyeL: [0, 1.15],
  eyeR: [0, 1.15],
  happyL: [0, 1],
  happyR: [0, 1],
  eyeTiltL: [-14, 14],
  eyeTiltR: [-14, 14],
  browY: [-4, 4],
  browTilt: [-18, 18],
  mouthW: [3, 15],
  mouthH: [0.8, 11],
  blush: [0, 1],
  tear: [0, 1],
  headTilt: [-7, 7],
  headY: [-3.2, 4.8],
  bodyY: [-3.5, 5.5],
  bodySX: [0.96, 1.045],
  bodySY: [0.96, 1.055],
  bodyTilt: [-4, 4],
  armL: [-36, 52],
  armR: [-52, 36],
  handIn: [0, 10],
  earLiftL: [-8, 32],
  earLiftR: [-8, 32],
  earInL: [-10, 22],
  earInR: [-10, 22],
  earRaiseL: [0, 1],
  earRaiseR: [0, 1],
  earSpreadL: [-1, 1],
  earSpreadR: [-1, 1],
  earCurlL: [-18, 38],
  earCurlR: [-18, 38],
  earTipL: [-4, 4],
  earTipR: [-4, 4],
  footLiftL: [0, 14],
  footLiftR: [0, 14],
  footXL: [-18, 18],
  footXR: [-18, 18],
  tail: [-20, 20],
  yawOffset: [-1, 1]
});
var EXPRESSIONS = Object.freeze({
  neutral: {},
  happy: { eyeL: 0.02, eyeR: 0.02, happyL: 1, happyR: 1, mouthShape: "open", mouthW: 9.6, mouthH: 4.3, blush: 0.34, earLiftL: 2, earLiftR: 2, headY: -0.35 },
  wink: { eyeL: 1, eyeR: 0.02, happyR: 1, mouthW: 9.3, mouthH: 3, blush: 0.2, headTilt: -1.7, earLiftR: 2.8 },
  love: { eyeL: 0.84, eyeR: 0.84, happyL: 0.85, happyR: 0.85, mouthShape: "open", mouthW: 8.7, mouthH: 3.4, blush: 0.62, handIn: 2.8, earInL: 2.5, earInR: 2.5, earCurlL: 4, earCurlR: 4, headTilt: -1 },
  shy: { eyeL: 0.78, eyeR: 0.78, eyeTiltL: -3, eyeTiltR: 3, mouthW: 7.3, mouthH: 2.1, blush: 0.78, headY: 1.2, headTilt: -2.7, handIn: 2.6, earInL: 3.1, earInR: 3.1, browY: 0.35 },
  surprised: { eyeL: 1.14, eyeR: 1.14, browY: -2.2, mouthShape: "o", mouthW: 5.9, mouthH: 7.5, headY: -0.85, earLiftL: 4.2, earLiftR: 4.2, armL: 5, armR: -5 },
  angry: { eyeL: 0.68, eyeR: 0.68, eyeTiltL: 9, eyeTiltR: -9, browY: 1.25, browTilt: -12, mouthShape: "sad", mouthW: 7.3, mouthH: 1.4, handIn: 2.2, earLiftL: 3.1, earLiftR: 3.1, earCurlL: 7, earCurlR: 7, blush: 0.12 },
  sad: { eyeL: 0.83, eyeR: 0.83, eyeTiltL: -3, eyeTiltR: 3, browY: -0.2, browTilt: 11, mouthShape: "sad", mouthW: 6.8, mouthH: 2.4, headY: 1.3, bodyY: 0.35, earLiftL: -2.2, earLiftR: -2.2, tail: -2 },
  sleepy: { eyeL: 0.46, eyeR: 0.46, mouthW: 7, mouthH: 1.8, browY: 0.4, headY: 1.25, earLiftL: -1.4, earLiftR: -1.4, earCurlL: 1.8, earCurlR: 1.8 },
  thinking: { eyeL: 0.86, eyeR: 0.91, browTilt: 5, mouthShape: "o", mouthW: 4.6, mouthH: 2.1, headTilt: 3.9, headY: -0.55, earLiftL: 0.5, earLiftR: 3.5, armR: -7, handIn: 1.2 },
  smug: { eyeL: 0.61, eyeR: 0.65, happyL: 0.65, happyR: 0.65, browY: -0.3, mouthW: 9.6, mouthH: 2.7, blush: 0.2, headTilt: -1.5, headY: -0.75, earLiftL: 1.7 },
  pout: { eyeL: 0.79, eyeR: 0.79, browY: 0.6, mouthShape: "o", mouthW: 4.8, mouthH: 2.8, blush: 0.47, headTilt: 1.6, handIn: 2.2, earInL: 2.5, earInR: 2.5 },
  worried: { eyeL: 0.95, eyeR: 0.95, browY: -0.8, browTilt: 12, mouthShape: "sad", mouthW: 6.1, mouthH: 2.2, headY: 0.5, handIn: 2.7, earInL: 2, earInR: 2, earLiftL: -1, earLiftR: -1 },
  determined: { eyeL: 0.81, eyeR: 0.81, eyeTiltL: 6, eyeTiltR: -6, browY: 0.7, browTilt: -9, mouthW: 7.2, mouthH: 1.7, handIn: 2.4, bodyY: -0.15, earLiftL: 1.8, earLiftR: 1.8 },
  flustered: { eyeL: 0.5, eyeR: 0.38, happyL: 0.75, happyR: 0.75, eyeTiltL: 7, eyeTiltR: -7, mouthShape: "open", mouthW: 6.9, mouthH: 3.7, blush: 0.87, browY: 0.5, handIn: 3.5, earLiftL: 3.8, earLiftR: 2.5, earCurlL: 8, earCurlR: 8 },
  scared: { eyeL: 1.1, eyeR: 1.1, browY: -1.8, browTilt: 13, mouthShape: "o", mouthW: 5.4, mouthH: 6.7, headY: 1.05, bodySX: 0.989, bodySY: 1.01, handIn: 5.5, earInL: 5.7, earInR: 5.7, earCurlL: 10, earCurlR: 10 },
  excited: { eyeL: 1.07, eyeR: 1.07, happyL: 0.8, happyR: 0.8, browY: -1, mouthShape: "open", mouthW: 9.7, mouthH: 4.8, blush: 0.39, headY: -0.7, bodySY: 1.009, earLiftL: 3.7, earLiftR: 3.7, armL: 4, armR: -4 },
  cry: { eyeL: 0.94, eyeR: 0.94, browY: -0.8, browTilt: 15, mouthShape: "sad", mouthW: 6.1, mouthH: 2.6, tear: 0.84, blush: 0.28, handIn: 2, headY: 1.3, earLiftL: -2.2, earLiftR: -2.2 },
  confused: { eyeL: 0.97, eyeR: 0.63, eyeTiltL: -2, eyeTiltR: 5, browY: -0.35, browTilt: 5.5, mouthShape: "o", mouthW: 5.1, mouthH: 3.6, headTilt: -3.2, earLiftL: 4.2, earLiftR: -0.5 },
  cozy: { eyeL: 0.19, eyeR: 0.19, happyL: 0.64, happyR: 0.64, mouthW: 8.2, mouthH: 2, blush: 0.18, headTilt: -0.65, headY: 0.45, earLiftL: -1, earLiftR: -1, earCurlL: 2.5, earCurlR: 2.5 },
  curious: { eyeL: 1.04, eyeR: 1.04, browY: -1.6, browTilt: 2, mouthW: 7.9, mouthH: 2.6, headTilt: 2.6, headY: -0.8, earLiftL: 0.7, earLiftR: 4.5, armR: -5 },
  bashful: { eyeL: 0.18, eyeR: 0.27, happyL: 1, happyR: 1, mouthShape: "open", mouthW: 7.8, mouthH: 3.2, blush: 0.82, headTilt: -2.1, headY: 0.65, handIn: 4.2, earInL: 3.8, earInR: 3.8, earCurlL: 5.5, earCurlR: 5.5 },
  pleading: { eyeL: 1.03, eyeR: 1.03, browY: -1.35, browTilt: 14, mouthShape: "o", mouthW: 5.4, mouthH: 2.1, tear: 0.2, blush: 0.24, headY: 0.7, handIn: 4, earLiftL: -1.1, earLiftR: -1.1, earInL: 2.7, earInR: 2.7 },
  proud: { eyeL: 0.76, eyeR: 0.76, happyL: 0.65, happyR: 0.65, browY: -0.5, mouthW: 9.8, mouthH: 2.6, headY: -1.65, headTilt: -1, bodySY: 1.012, earLiftL: 1.5, earLiftR: 1.5, armL: 2.5, armR: -2.5 },
  sparkle: { eyeL: 1.15, eyeR: 1.15, happyL: 0.35, happyR: 0.35, browY: -2, mouthShape: "open", mouthW: 8.6, mouthH: 5.6, blush: 0.43, headY: -1.1, bodyY: -0.45, bodyTilt: 0.55, handIn: 1.3, earLiftL: 4.2, earLiftR: 4.2 }
});
var ALIASES = Object.freeze({ content: "cozy", waking: "sleepy", listening: "curious", run: "excited", dragged: "flustered", dizzy: "confused", sleep: "sleepy", bowing: "neutral", squeeze: "neutral" });
var SCHEMES = Object.freeze({ gentle: { movement: 0.84, tipOmega: 10.7, tipIdle: 0.12 }, lively: { movement: 1.08, tipOmega: 12.1, tipIdle: 0.2 } });
var BODY_KEYS = ["headTilt", "headY", "bodyY", "bodySX", "bodySY", "bodyTilt", "armL", "armR", "handIn", "earLiftL", "earLiftR", "earRaiseL", "earRaiseR", "earSpreadL", "earSpreadR", "earInL", "earInR", "earCurlL", "earCurlR", "footLiftL", "footLiftR", "footXL", "footXR", "tail"];
var TIPS = /* @__PURE__ */ new Set(["earTipL", "earTipR"]);
var add = (pose, values) => {
  for (const [key, value] of Object.entries(values)) pose[key] += value;
};
function mouth(pose, shape, width, height, weight = 1) {
  weight = unit(weight);
  pose.mouthW = mix(pose.mouthW, width, weight);
  pose.mouthH = mix(pose.mouthH, height, weight);
  for (const key of SHAPES) pose._mouthMix[key] = mix(pose._mouthMix[key], key === shape ? 1 : 0, weight);
}
function keypath(k, stops) {
  for (let i = 1; i < stops.length; i++) if (k <= stops[i][0]) {
    const [a, av] = stops[i - 1], [b, bv] = stops[i];
    return mix(av, bv, smooth((k - a) / (b - a)));
  }
  return stops.at(-1)[1];
}
var GESTURES = {
  nod(p, k) {
    const e = bell(k);
    add(p, { headY: 1.9 * e, headTilt: 1.1 * e, bodyY: 0.25 * e, armL: 1.5 * e, armR: -1.5 * e, earCurlL: 2.7 * e, earCurlR: 2.7 * e, tail: 1.5 * e });
  },
  shake(p, k) {
    const e = envelope(k, 0.16, 0.76), w = Math.sin(TAU * 2 * k) * e;
    add(p, { yawOffset: 0.055 * w, headTilt: 2.1 * w, bodyTilt: -0.45 * w, armL: 1.8 * w, armR: 1.8 * w, earInL: 1.4 * w, earInR: -1.4 * w, earLiftL: 0.7 * w, earLiftR: -0.7 * w });
  },
  spin(p, k) {
    const e = envelope(k, 0.12, 0.87), w = Math.sin(TAU * k) * e;
    add(p, { yawOffset: 0.24 * w, headTilt: 1.1 * w, bodyTilt: 0.55 * w, earLiftL: 1.5 * Math.max(w, 0), earLiftR: 1.5 * Math.max(-w, 0), earInL: -0.8 * w, earInR: 0.8 * w, armL: 2.5 * w, armR: 2.5 * w, tail: 3 * w });
  },
  wave(p, k) {
    const e = envelope(k, 0.2, 0.78), w = Math.sin(TAU * 2.1 * k) * e;
    add(p, { armL: 39 * e + 5.5 * w, armR: -3.5 * e, earLiftL: 8 * e + 1.7 * w, earLiftR: 1.8 * e, earCurlL: -3 * e, headTilt: -1.5 * e, bodyY: -0.35 * e, handIn: 0.4 * e, footLiftR: 0.3 * e, tail: 3 * w });
  },
  bow(p, k) {
    const e = envelope(k, 0.25, 0.66);
    add(p, { headY: 3.1 * e, headTilt: 2.6 * e, bodyY: 0.7 * e, bodySY: -0.011 * e, bodySX: 7e-3 * e, armL: 5 * e, armR: -5 * e, earLiftL: -1.3 * e, earLiftR: -1.3 * e, earInL: 2 * e, earInR: 2 * e, tail: -3.2 * e });
    p.eyeL *= 1 - 0.98 * e;
    p.eyeR *= 1 - 0.98 * e;
    p.happyL *= 1 - e;
    p.happyR *= 1 - e;
  },
  shiver(p, k) {
    const e = envelope(k, 0.16, 0.74), w = Math.sin(TAU * 4 * k) * e;
    add(p, { bodySX: -9e-3 * e, bodySY: 7e-3 * e, bodyY: 0.4 * e, headTilt: 0.48 * w, handIn: 3.4 * e, armL: -5 * e, armR: 5 * e, earLiftL: 2.6 * e + 0.5 * w, earLiftR: 2.6 * e - 0.5 * w, earCurlL: 8 * e, earCurlR: 8 * e, tail: 1.3 * w });
  },
  flap(p, k) {
    const e = envelope(k, 0.12, 0.84), w = Math.sin(TAU * 1.5 * k), beat = w * w * e;
    add(p, { earLiftL: 13.5 * beat, earLiftR: 13.5 * beat, earInL: -2 * e, earInR: -2 * e, earCurlL: -5 * beat, earCurlR: -5 * beat, armL: 14 * e, armR: -14 * e, bodyY: -0.35 * beat, headY: -0.2 * beat, footLiftL: 0.7 * e, footLiftR: 0.7 * e, tail: 2.5 * w * e });
  },
  "ear-wave"(p, k) {
    const e = envelope(k, 0.24, 0.75), w = Math.sin(TAU * 2 * k) * e;
    add(p, { earLiftL: 18 * e + 3.2 * w, earLiftR: 2.5 * e, earInL: 2.2 * e + 0.9 * w, earInR: -0.8 * e, earCurlL: -9 * e + 3.5 * w, earCurlR: 2 * e, armL: 11 * e, armR: -2 * e, headTilt: -1.9 * e, bodyTilt: 0.65 * e, bodyY: -0.35 * e, footLiftR: 0.3 * e, tail: 3.7 * w });
  },
  "ear-fold"(p, k) {
    const e = envelope(k, 0.27, 0.69);
    add(p, { earLiftL: 5 * e, earLiftR: 5 * e, earInL: 14.5 * e, earInR: 14.5 * e, earCurlL: 25 * e, earCurlR: 25 * e, handIn: 6.4 * e, armL: -7 * e, armR: 7 * e, bodySY: -0.012 * e, bodySX: 9e-3 * e, headY: 0.9 * e, headTilt: 0.45 * e, blush: 0.15 * e, tail: 3.2 * e });
  },
  cuddle(p, k) {
    const e = envelope(k, 0.3, 0.73), prepare = bell(k / 0.24);
    add(p, { bodyY: 0.5 * prepare - 0.85 * e, bodySY: 0.021 * e, bodySX: 0.01 * e, headY: -0.55 * e, headTilt: -1.2 * e, handIn: 5.4 * e, armL: -10 * e, armR: 10 * e, earInL: 9 * e, earInR: 9 * e, earCurlL: 16 * e, earCurlR: 16 * e, earLiftL: 5 * e, earLiftR: 5 * e, blush: 0.13 * e, tail: 5 * e + Math.sin(TAU * k) * e });
  },
  peek(p, k) {
    const e = envelope(k, 0.14, 0.86), y = keypath(k, [[0, 0], [0.26, -0.45], [0.37, -0.45], [0.64, 0.51], [0.77, 0.51], [1, 0]]);
    add(p, { yawOffset: y, headTilt: 2.4 * y, headY: -0.3 * e, bodyTilt: 0.85 * y, earLiftL: 4.5 * Math.max(y, 0), earLiftR: 4.5 * Math.max(-y, 0), earInL: -0.8 * e, earInR: -0.8 * e, earCurlL: 2.2 * e, earCurlR: 2.2 * e, armL: 3 * e, armR: -3 * e, handIn: 1.2 * e, tail: -4 * y });
  },
  stretch(p, k) {
    const e = envelope(k, 0.38, 0.66);
    add(p, { bodySY: 0.034 * e, bodySX: -0.021 * e, bodyY: -0.5 * e, headY: -0.5 * e, armL: 28 * e, armR: -28 * e, earLiftL: 21 * e, earLiftR: 21 * e, earInL: -3.7 * e, earInR: -3.7 * e, earCurlL: -7 * e, earCurlR: -7 * e, tail: 7 * e });
    p.eyeL *= 1 - 0.86 * e;
    p.eyeR *= 1 - 0.86 * e;
    p.happyL *= 1 - e;
    p.happyR *= 1 - e;
    mouth(p, "o", 6.1, 6.8, e);
  },
  sway(p, k) {
    const e = envelope(k, 0.18, 0.84), w = Math.sin(TAU * 2 * k) * e;
    add(p, { bodyTilt: 1.8 * w, headTilt: -1.3 * w, bodyY: -0.18 * w * w, earLiftL: 2.8 * w, earLiftR: -2.8 * w, earInL: w, earInR: -w, armL: 4 * e + 2.5 * w, armR: -4 * e + 2.5 * w, footLiftL: 0.5 * Math.max(w, 0), footLiftR: 0.5 * Math.max(-w, 0), tail: 6.5 * w });
  },
  bounce(p, k) {
    const e = envelope(k, 0.1, 0.86), w = Math.sin(TAU * 2 * (k - 0.11)), up = Math.max(w, 0) * envelope(k, 0.23, 0.84), settle = Math.max(-w, 0) * e;
    add(p, { tail: 11 * Math.sin(TAU * 2.5 * k) * e, bodyY: -1.7 * up + 0.35 * settle, bodySY: 0.021 * up - 7e-3 * settle, bodySX: -0.01 * up + 6e-3 * settle, headY: -0.2 * up, earLiftL: 4.5 * up, earLiftR: 4.5 * up, earCurlL: 3 * up, earCurlR: 3 * up, armL: 7 * up, armR: -7 * up, footLiftL: 0.5 * up, footLiftR: 0.5 * up });
  },
  doze(p, k) {
    const e = envelope(k, 0.42, 0.77), recover = bell((k - 0.71) / 0.24);
    add(p, { headY: 2.8 * e - 0.5 * recover, headTilt: 1.8 * e, bodyY: 0.65 * e, bodySY: -7e-3 * e, earLiftL: -2.8 * e, earLiftR: -2.8 * e, earInL: 2.5 * e, earInR: 2.5 * e, earCurlL: 3.5 * e, earCurlR: 3.5 * e, handIn: 1.6 * e, tail: -2 * e });
    p.eyeL = mix(p.eyeL * (1 - 0.94 * e), 0.9, recover * 0.8);
    p.eyeR = mix(p.eyeR * (1 - 0.94 * e), 0.9, recover * 0.8);
    p.happyL *= 1 - e;
    p.happyR *= 1 - e;
    mouth(p, "o", 5.3, 4.9, 0.72 * bell((k - 0.18) / 0.52));
  },
  greet(p, k, frame) {
    const e = envelope(k, 0.22, 0.8), w = Math.sin(TAU * 2 * k) * e, nod = bell(k / 0.3);
    add(p, { armL: 28 * e + 6 * w, armR: -4 * e, earLiftL: 11 * e + 1.8 * w, earLiftR: 3 * e, earCurlL: -3 * e, headY: -0.8 * e + 0.35 * nod, headTilt: -1.15 * e, bodyY: -0.3 * e, handIn: 0.45 * e, yawOffset: -0.18 * clamp2(finite(frame.viewYaw), -1, 1) * e, footLiftR: 0.25 * e, tail: 4 * w });
  },
  celebrate(p, k) {
    const e = envelope(k, 0.17, 0.84), w = Math.sin(TAU * 3 * k), left = Math.max(w, 0) * e, right = Math.max(-w, 0) * e;
    add(p, { armL: 19 * e + 13 * left, armR: -19 * e - 13 * right, earLiftL: 8 * e + 9 * left, earLiftR: 8 * e + 9 * right, earInL: -1.3 * e, earInR: -1.3 * e, earCurlL: 5 * e + 3 * left, earCurlR: 5 * e + 3 * right, bodyY: -0.85 * e - 0.45 * Math.abs(w) * e, bodySY: 0.015 * e, bodyTilt: 1.05 * w * e, headTilt: -1.2 * w * e, footLiftL: left, footLiftR: right, tail: 8 * w * e });
    mouth(p, "open", 9.4, 5.3 + 0.6 * Math.abs(w), e * 0.7);
  }
};
var EAR_ACTIONS = {
  nod(p, k) {
    const e = bell(k);
    add(p, { earRaiseL: 0.27 * e, earRaiseR: 0.27 * e, earSpreadL: -0.14 * e, earSpreadR: -0.14 * e });
  },
  shake(p, k) {
    const e = envelope(k, 0.16, 0.76), w = Math.sin(TAU * 2 * k) * e;
    add(p, { earRaiseL: 0.24 * e + 0.12 * Math.max(w, 0), earRaiseR: 0.24 * e + 0.12 * Math.max(-w, 0), earSpreadL: 0.32 * w, earSpreadR: -0.32 * w });
  },
  spin(p, k) {
    const e = envelope(k, 0.12, 0.87), w = Math.sin(TAU * k) * e;
    add(p, { earRaiseL: 0.36 * e + 0.2 * Math.max(w, 0), earRaiseR: 0.36 * e + 0.2 * Math.max(-w, 0), earSpreadL: 0.44 * w, earSpreadR: -0.44 * w });
  },
  wave(p, k) {
    const e = envelope(k, 0.2, 0.78), w = Math.sin(TAU * 2.1 * k) * e;
    add(p, { earRaiseL: 0.68 * e + 0.2 * w, earRaiseR: 0.23 * e, earSpreadL: 0.48 * e + 0.12 * w, earSpreadR: 0.18 * e });
  },
  bow(p, k) {
    const e = envelope(k, 0.25, 0.66), release = bell((k - 0.65) / 0.35);
    add(p, { earRaiseL: 0.15 * e + 0.2 * release, earRaiseR: 0.15 * e + 0.2 * release, earSpreadL: -0.28 * e, earSpreadR: -0.28 * e, earCurlL: 8 * e, earCurlR: 8 * e });
  },
  shiver(p, k) {
    const e = envelope(k, 0.16, 0.74), w = Math.sin(TAU * 4 * k) * e;
    add(p, { earRaiseL: 0.32 * e + 0.06 * w, earRaiseR: 0.32 * e - 0.06 * w, earSpreadL: -0.24 * e + 0.13 * w, earSpreadR: -0.24 * e - 0.13 * w });
  },
  flap(p, k) {
    const e = envelope(k, 0.12, 0.84), beat = Math.sin(TAU * 1.5 * k) ** 2 * e;
    add(p, { earRaiseL: 0.14 * e + 1.02 * beat, earRaiseR: 0.14 * e + 1.02 * beat, earSpreadL: 0.2 * e + 0.62 * beat, earSpreadR: 0.2 * e + 0.62 * beat });
  },
  "ear-wave"(p, k) {
    const e = envelope(k, 0.24, 0.75), w = Math.sin(TAU * 2 * k) * e;
    add(p, { earRaiseL: 0.88 * e + 0.22 * w, earRaiseR: 0.22 * e + 0.08 * Math.max(-w, 0), earSpreadL: 0.55 * e + 0.2 * w, earSpreadR: 0.16 * e - 0.08 * w });
  },
  "ear-fold"(p, k) {
    const e = envelope(k, 0.27, 0.69);
    add(p, { earRaiseL: 0.3 * e, earRaiseR: 0.3 * e, earSpreadL: -0.7 * e, earSpreadR: -0.7 * e });
  },
  cuddle(p, k) {
    const e = envelope(k, 0.3, 0.73);
    add(p, { earRaiseL: 0.22 * e, earRaiseR: 0.22 * e, earSpreadL: -0.48 * e, earSpreadR: -0.48 * e });
  },
  peek(p, k) {
    const e = envelope(k, 0.14, 0.86), y = keypath(k, [[0, 0], [0.26, -0.45], [0.37, -0.45], [0.64, 0.51], [0.77, 0.51], [1, 0]]);
    add(p, { earRaiseL: 0.2 * e + 0.4 * Math.max(y / 0.51, 0), earRaiseR: 0.2 * e + 0.4 * Math.max(-y / 0.45, 0), earSpreadL: 0.13 * e + 0.22 * y, earSpreadR: 0.13 * e - 0.22 * y });
  },
  stretch(p, k) {
    const e = envelope(k, 0.38, 0.66);
    add(p, { earRaiseL: 0.98 * e, earRaiseR: 0.98 * e, earSpreadL: 0.76 * e, earSpreadR: 0.76 * e });
  },
  sway(p, k) {
    const e = envelope(k, 0.18, 0.84), w = Math.sin(TAU * 2 * k) * e;
    add(p, { earRaiseL: 0.32 * e + 0.26 * w, earRaiseR: 0.32 * e - 0.26 * w, earSpreadL: 0.4 * w, earSpreadR: -0.4 * w });
  },
  bounce(p, k) {
    const e = envelope(k, 0.1, 0.86), up = Math.max(Math.sin(TAU * 2 * (k - 0.11)), 0) * envelope(k, 0.23, 0.84);
    add(p, { earRaiseL: 0.13 * e + 0.65 * up, earRaiseR: 0.13 * e + 0.65 * up, earSpreadL: 0.14 * e + 0.4 * up, earSpreadR: 0.14 * e + 0.4 * up });
  },
  doze(p, k) {
    const e = envelope(k, 0.42, 0.77), recover = bell((k - 0.71) / 0.24);
    add(p, { earRaiseL: 0.1 * e + 0.35 * recover, earRaiseR: 0.1 * e + 0.35 * recover, earSpreadL: -0.22 * e + 0.18 * recover, earSpreadR: -0.22 * e + 0.18 * recover });
  },
  greet(p, k) {
    const e = envelope(k, 0.22, 0.8), w = Math.sin(TAU * 2 * k) * e;
    add(p, { earRaiseL: 0.77 * e + 0.18 * w, earRaiseR: 0.32 * e + 0.08 * Math.max(-w, 0), earSpreadL: 0.48 * e + 0.13 * w, earSpreadR: 0.22 * e });
  },
  celebrate(p, k) {
    const e = envelope(k, 0.17, 0.84), w = Math.sin(TAU * 3 * k), left = Math.max(w, 0) * e, right = Math.max(-w, 0) * e;
    add(p, { earRaiseL: 0.43 * e + 0.72 * left, earRaiseR: 0.43 * e + 0.72 * right, earSpreadL: 0.28 * e + 0.5 * left, earSpreadR: 0.28 * e + 0.5 * right });
  }
};
function groundCycle(phase, swingFraction) {
  const u = ((phase / TAU + 0.25) % 1 + 1) % 1;
  if (u >= swingFraction) return { x: 1 - 2 * (u - swingFraction) / (1 - swingFraction), lift: 0, support: true };
  const k = u / swingFraction, tangent = -2 * swingFraction / (1 - swingFraction);
  return {
    x: -1 + 2 * smooth(k) + tangent * (2 * k * k * k - 3 * k * k + k),
    lift: Math.sin(Math.PI * k) ** 2,
    support: false
  };
}
function modePose(p, frame, t) {
  const mode = typeof frame.mode === "string" ? frame.mode : "idle";
  const sit = unit(frame.sit), drowse = unit(frame.drowse), mt = Math.max(0, finite(frame.modeT));
  add(p, { bodyY: 0.5 * sit, bodySX: 5e-3 * sit, bodySY: -7e-3 * sit, handIn: 0.45 * sit, earCurlL: 1.4 * sit, earCurlR: 1.4 * sit });
  p.eyeL *= 1 - 0.5 * drowse;
  p.eyeR *= 1 - 0.5 * drowse;
  const look = Array.isArray(frame.lookScreen) ? frame.lookScreen : [0, 0];
  p.headTilt += clamp2(finite(look[0]), -6, 6) * 0.085;
  p.headY += clamp2(finite(look[1]), -6, 6) * 0.025;
  const looking = clamp2(finite(look[0]) / 5, -1, 1), lookUp = unit(-finite(look[1]) / 4);
  const turning = clamp2(finite(frame.viewYawTarget, finite(frame.viewYaw)) - finite(frame.viewYaw), -1, 1);
  const turnEnergy = Math.abs(turning);
  add(p, {
    earRaiseL: 0.14 * turnEnergy + 0.12 * Math.max(turning, 0),
    earRaiseR: 0.14 * turnEnergy + 0.12 * Math.max(-turning, 0),
    earSpreadL: -0.24 * turning,
    earSpreadR: 0.24 * turning,
    earCurlL: 5 * turning,
    earCurlR: -5 * turning
  });
  if (sit) add(p, { earSpreadL: -0.16 * sit, earSpreadR: -0.16 * sit, earCurlL: 1.8 * sit, earCurlR: 1.8 * sit });
  if (mode === "walk" || mode === "run" || mode === "dance") {
    const legs = Array.isArray(frame.legsScreen) ? frame.legsScreen : [];
    const left = legs[0] ?? [], right = legs[1] ?? [];
    const run = mode === "run", dance = mode === "dance";
    const nominalStride = run ? 17 : dance ? 5 : 10, nominalLift = run ? 15 : dance ? 10 : 8;
    const dxL = clamp2(finite(left[2], finite(left[0])) - finite(left[0]), -24, 24);
    const dxR = clamp2(finite(right[2], finite(right[0])) - finite(right[0]), -24, 24);
    const liftL = clamp2(241 - finite(left[3], 241), 0, 24), liftR = clamp2(241 - finite(right[3], 241), 0, 24);
    let strideL = clamp2(dxL / nominalStride, -1, 1), strideR = clamp2(dxR / nominalStride, -1, 1);
    let stepL = unit(liftL / nominalLift), stepR = unit(liftR / nominalLift);
    const liftGain = run ? 1.05 : dance ? 1.15 : 1.2, strideGain = run ? 1.05 : dance ? 1.8 : 1.4;
    if (dance) {
      p.footLiftL += liftL * liftGain;
      p.footLiftR += liftR * liftGain;
      p.footXL += dxL * strideGain;
      p.footXR += dxR * strideGain;
    } else {
      const heading = finite(frame.heading, finite(frame.viewYaw) < 0 ? -1 : 1) < 0 ? -1 : 1;
      const sine = (dxL - dxR) * heading / (2 * nominalStride), cosine = (liftL - liftR) / nominalLift;
      const amplitude = clamp2(Math.hypot(sine, cosine), 0, 1.05), phase = Math.atan2(sine, cosine);
      const swingFraction = run ? 0.48 : 0.44;
      const leftCycle = groundCycle(phase, swingFraction), rightCycle = groundCycle(phase + Math.PI, swingFraction);
      strideL = clamp2(leftCycle.x * amplitude * heading, -1.1, 1.1);
      strideR = clamp2(rightCycle.x * amplitude * heading, -1.1, 1.1);
      stepL = leftCycle.lift * amplitude;
      stepR = rightCycle.lift * amplitude;
      p.footXL += strideL * nominalStride * strideGain;
      p.footXR += strideR * nominalStride * strideGain;
      p.footLiftL += stepL * nominalLift * liftGain;
      p.footLiftR += stepR * nominalLift * liftGain;
      p._gait = {
        source: "native endpoint phase",
        phase,
        amplitude,
        heading,
        swingFraction,
        supportL: leftCycle.support,
        supportR: rightCycle.support,
        kinematicBlend: smooth(mt / 0.18)
      };
    }
    const armGain = run ? 30 : dance ? 27 : 24, armOpen = dance ? 12 : 7;
    p.armL += armOpen + armGain * strideL;
    p.armR += -armOpen + armGain * strideR;
    const baseRaise = run ? 0.37 : dance ? 0.24 : 0.3, beatRaise = run ? 0.34 : dance ? 0.43 : 0.27;
    p.earRaiseL += baseRaise + beatRaise * stepR + 0.07 * stepL;
    p.earRaiseR += baseRaise + beatRaise * stepL + 0.07 * stepR;
    const baseSpread = run ? 0.21 : dance ? 0.27 : 0.16, spreadBeat = run ? 0.23 : dance ? 0.27 : 0.18;
    p.earSpreadL += baseSpread + spreadBeat * strideR;
    p.earSpreadR += baseSpread + spreadBeat * strideL;
    p.earLiftL += (run ? 6 : 4) * stepR;
    p.earLiftR += (run ? 6 : 4) * stepL;
    p.earCurlL += (run ? 8 : 6) * strideL;
    p.earCurlR += (run ? 8 : 6) * strideR;
    p.tail += (strideL - strideR) * (run ? 5 : dance ? 4.5 : 3.2);
  } else if (mode === "look") {
    add(p, {
      earRaiseL: 0.14 + 0.22 * lookUp + 0.2 * Math.max(looking, 0),
      earRaiseR: 0.14 + 0.22 * lookUp + 0.2 * Math.max(-looking, 0),
      earSpreadL: 0.13 - 0.2 * looking,
      earSpreadR: 0.13 + 0.2 * looking
    });
  } else if (mode === "wake") {
    const e = envelope(unit(mt / 1.8), 0.38, 0.72);
    add(p, {
      earRaiseL: 0.7 * e,
      earRaiseR: 0.7 * e,
      earSpreadL: 0.45 * e,
      earSpreadR: 0.45 * e,
      earLiftL: 5 * e,
      earLiftR: 5 * e,
      armL: 10 * e,
      armR: -10 * e
    });
  } else if (mode === "sit") {
    const e = bell(mt / 1.1);
    add(p, { earRaiseL: 0.2 * e, earRaiseR: 0.2 * e, earSpreadL: -0.08 * e, earSpreadR: -0.08 * e });
  } else if (mode === "idle") {
    const e = bell(mt / 0.8);
    add(p, {
      earRaiseL: 0.2 * e + 0.06 * lookUp,
      earRaiseR: 0.2 * e + 0.06 * lookUp,
      earSpreadL: 0.11 * e,
      earSpreadR: 0.11 * e
    });
  } else if (mode === "crouch") {
    add(p, { bodyY: 0.45, bodySX: 6e-3, bodySY: -8e-3, handIn: 1.2, earLiftL: 1.5, earLiftR: 1.5, earInL: 0.7, earInR: 0.7, tail: -2.2 });
    add(p, { earRaiseL: 0.22, earRaiseR: 0.22, earSpreadL: -0.17, earSpreadR: -0.17 });
  } else if (mode === "air") {
    add(p, { armL: 9, armR: -9, earInL: 2.2, earInR: 2.2, earLiftL: 3.5, earLiftR: 3.5, earCurlL: -3, earCurlR: -3, footLiftL: 1.2, footLiftR: 1.2, tail: -3.5 });
    const flapping = frame.gesture?.kind === "flap", raise = flapping ? 0.06 : 0.61 + 0.15 * bell(mt / 0.55);
    add(p, {
      earRaiseL: raise,
      earRaiseR: raise,
      earSpreadL: flapping ? 0.04 : 0.5,
      earSpreadR: flapping ? 0.04 : 0.5,
      footLiftL: 3.5,
      footLiftR: 3.5,
      footXL: -3,
      footXR: 3
    });
  } else if (mode === "land") {
    const e = Math.exp(-9 * mt);
    add(p, { bodyY: 0.55 * e, headY: 0.25 * e, earLiftL: -2.8 * e, earLiftR: -2.8 * e, tail: 2.8 * e });
    const rebound = bell(mt / 0.4);
    add(p, { earRaiseL: 0.3 * rebound, earRaiseR: 0.3 * rebound, earSpreadL: 0.2 * rebound, earSpreadR: 0.2 * rebound });
  } else if (mode === "drag") {
    add(p, { bodySY: 9e-3, armL: 15, armR: -15, earLiftL: 4, earLiftR: 4, earInL: 0.8, earInR: 0.8, footLiftL: 0.3, footLiftR: 0.3 });
    const wind = clamp2(finite(frame.swingScreen) / 40, -1, 1);
    add(p, { earRaiseL: 0.4 + 0.2 * Math.abs(wind), earRaiseR: 0.4 + 0.2 * Math.abs(wind), earSpreadL: 0.36 + 0.16 * wind, earSpreadR: 0.36 - 0.16 * wind });
  } else if (mode === "dizzy") {
    const e = envelope(clamp2(mt / 3.2, 0, 1), 0.12, 0.78), w = Math.sin(t * 4.5) * e;
    add(p, { headTilt: -0.5 * w, armL: 2.2 * w, armR: 2.2 * w, earInL: w, earInR: -w, tail: 2.5 * w });
    add(p, { earRaiseL: 0.25 * e + 0.14 * w, earRaiseR: 0.25 * e - 0.14 * w, earSpreadL: 0.4 * w, earSpreadR: -0.4 * w });
  }
  if (mode === "sleep" || frame.face === "sleep") {
    p.eyeL = p.eyeR = p.happyL = p.happyR = 0;
    add(p, { headY: 0.7, headTilt: -0.7, earLiftL: -1.4, earLiftR: -1.4 });
    const breath = Math.sin(t * 1.7);
    add(p, {
      earSpreadL: -0.18 + 0.025 * breath,
      earSpreadR: -0.18 + 0.025 * breath,
      earCurlL: 3.5 + 0.8 * breath,
      earCurlR: 3.5 + 0.8 * breath
    });
    mouth(p, "smile", 6.5, 1.6);
  }
  if (frame.face === "bowing" || frame.face === "squeeze") p.eyeL = p.eyeR = p.happyL = p.happyR = 0;
}
function targetPose(frame, t, age, movement, profile) {
  const rawFace = typeof frame.face === "string" ? frame.face : "neutral";
  const face = Object.hasOwn(EXPRESSIONS, rawFace) ? rawFace : ALIASES[rawFace] ?? "neutral";
  const p = { ...BASE, ...EXPRESSIONS[face] };
  p._mouthMix = oneMouth(p.mouthShape ?? "smile");
  delete p.mouthShape;
  if (face === "sleepy" && frame.mode !== "sleep") mouth(p, "o", 5.5, 5.8, 0.8 * bell((age - 0.5) / 2.2));
  if (face === "flustered") p.headTilt += 0.7 * Math.sin(age * 13) * Math.exp(-age * 1.8);
  modePose(p, frame, t);
  const gesture = frame.gesture;
  if (gesture && typeof GESTURES[gesture.kind] === "function") {
    const k = unit(gesture.k);
    GESTURES[gesture.kind](p, k, frame);
    EAR_ACTIONS[gesture.kind](p, k);
  }
  for (const key of BODY_KEYS) p[key] = BASE[key] + (p[key] - BASE[key]) * movement;
  const talk = unit(frame.talk);
  if (talk) {
    p.mouthW += 1.2 * talk;
    p.mouthH += 3.8 * talk;
    const openWeight = 0.56 * talk * (1 - p._mouthMix.o);
    for (const key of SHAPES) p._mouthMix[key] = mix(p._mouthMix[key], key === "open" ? 1 : 0, openWeight);
  }
  const swing = clamp2(finite(frame.swingScreen), -40, 40);
  const idle = profile.tipIdle * (frame.mode === "sleep" ? 0.35 : 1);
  p.earTipL = -0.065 * p.earLiftL + 0.04 * p.earInL + 0.015 * p.earCurlL - 2.4 * p.earRaiseL + 0.75 * p.earSpreadL + 0.05 * swing + idle * Math.sin(t * 1.43);
  p.earTipR = -0.065 * p.earLiftR + 0.04 * p.earInR + 0.015 * p.earCurlR - 2.4 * p.earRaiseR + 0.75 * p.earSpreadR - 0.05 * swing + idle * Math.sin(t * 1.43 + 0.6);
  for (const key of Object.keys(BASE)) p[key] = clamp2(finite(p[key], BASE[key]), ...LIMITS[key]);
  return p;
}
function follow(x, previous, target, rate, dt) {
  if (!dt) return x;
  const z = rate * dt, ease = -Math.expm1(-z);
  const ramp = z < 1e-4 ? z / 2 - z * z / 6 : 1 - ease / z;
  return x * (1 - ease) + previous * ease + (target - previous) * ramp;
}
function spring(state, target, omega, dt) {
  if (!dt) return;
  const damping = 0.84, damped = omega * Math.sqrt(1 - damping * damping);
  const decay = Math.exp(-damping * omega * dt), angle = damped * dt;
  const c = Math.cos(angle), s = Math.sin(angle), d = state.x - target, v = state.v;
  state.x = target + decay * (d * c + (v + damping * omega * d) * s / damped);
  state.v = decay * (v * c - (damping * omega * v + omega * omega * d) * s / damped);
  const bounded = clamp2(state.x, -4, 4);
  if (bounded !== state.x) state.v = 0;
  state.x = bounded;
  state.v = clamp2(state.v, -45, 45);
}
var rateFor = (key) => key === "yawOffset" ? 22 : key.startsWith("eye") || key.startsWith("happy") ? 18 : key.startsWith("mouth") ? 20 : key.startsWith("foot") ? 36 : key.startsWith("arm") ? 24 : key.startsWith("earRaise") ? 16 : key.startsWith("earSpread") ? 12 : key.startsWith("ear") ? 13 : 11;
var ANIMATION_CONTRACT = Object.freeze({
  version: 2,
  expressionIds: Object.freeze(Object.keys(EXPRESSIONS)),
  gestureIds: Object.freeze(Object.keys(GESTURES)),
  customGestureIds: Object.freeze(["ear-wave", "ear-fold", "cuddle", "peek", "stretch", "sway", "bounce", "doze", "greet", "celebrate"]),
  customSeconds: Object.freeze({ "ear-wave": 2.2, "ear-fold": 2.7, cuddle: 3, peek: 2.8, stretch: 3.2, sway: 3, bounce: 2.4, doze: 3.6, greet: 2.5, celebrate: 3.3 }),
  nativeModePaths: Object.freeze(["stand/wake", "jump/crouch/air/land", "hop/crouch/air/land", "look", "turn/viewYaw", "sit", "sleep", "dizzy", "walk", "run", "dance"]),
  schemes: Object.freeze(Object.keys(SCHEMES)),
  motionFields: Object.freeze({
    footXL: Object.freeze({ range: Object.freeze([-18, 18]), unit: "screen-signed logical dx; never mirror again" }),
    footXR: Object.freeze({ range: Object.freeze([-18, 18]), unit: "screen-signed logical dx; never mirror again" }),
    footLift: Object.freeze({ range: Object.freeze([0, 14]), unit: "logical up displacement, separate left/right" }),
    earRaise: Object.freeze({ range: Object.freeze([0, 1]), unit: "fixed-root whole-ear raised keyform, separate left/right" }),
    earSpread: Object.freeze({ range: Object.freeze([-1, 1]), unit: "fixed-root opening; positive is outwards on either side" })
  }),
  gait: Object.freeze({
    source: "native legsScreen endpoint phase and amplitude",
    footY: 241,
    nativeStride: Object.freeze({ walk: 10, run: 17, dance: 5 }),
    nativeLift: Object.freeze({ walk: 8, run: 15, dance: 10 }),
    swingFraction: Object.freeze({ walk: 0.44, run: 0.48 }),
    supportStroke: "linear with zero sole lift",
    swingStroke: "C1 cubic horizontal / sin-squared vertical",
    armPhase: "opposed screen rotation, contralateral to feet",
    noIndependentPhase: true,
    worldSpaceFootLock: false
  }),
  noHeadScale: true,
  clock: "native frame.t, frame.modeT, frame.gesture.k and legsScreen"
});
function createAnimator({ scheme = "gentle" } = {}) {
  if (!Object.hasOwn(SCHEMES, scheme)) throw new RangeError(`Unknown animation scheme: ${scheme}`);
  let schemeId = scheme, movement = SCHEMES[scheme].movement;
  let current = { ...BASE }, mouthMix = oneMouth("smile"), previous = null;
  let lastT = null, faceStartT = 0, faceName = null, lastInput = null, lastPose = null;
  const tips = { L: { x: 0, v: 0 }, R: { x: 0, v: 0 } };
  const counters = { steps: 0, zeroDt: 0, longDt: 0, invalidDt: 0, backwardsTime: 0 };
  function step(frame = {}) {
    const suppliedT = finite(frame.t, lastT ?? 0);
    let rawDt = Number.isFinite(frame.dt) ? frame.dt : lastT === null ? 0 : suppliedT - lastT;
    if (!Number.isFinite(rawDt) || rawDt < 0) {
      rawDt = 0;
      counters.invalidDt++;
    }
    if (rawDt === 0) counters.zeroDt++;
    if (rawDt > 0.12) counters.longDt++;
    const dt = Math.min(rawDt, 0.12);
    const t = Number.isFinite(frame.t) ? frame.t : (lastT ?? 0) + dt;
    if (lastT !== null && t < lastT - 1e-7) {
      counters.backwardsTime++;
      tips.L.v = tips.R.v = 0;
      faceStartT = t;
    }
    const face = typeof frame.face === "string" ? frame.face : "neutral";
    if (face !== faceName) {
      faceName = face;
      faceStartT = t;
    }
    const profile = SCHEMES[schemeId];
    movement += (profile.movement - movement) * -Math.expm1(-7 * dt);
    const target = targetPose(frame, t, Math.max(0, t - faceStartT), movement, profile);
    if (!previous) {
      current = Object.fromEntries(Object.keys(BASE).map((key) => [key, target[key]]));
      mouthMix = { ...target._mouthMix };
      tips.L.x = target.earTipL;
      tips.R.x = target.earTipR;
    } else {
      for (const key of Object.keys(BASE)) if (!TIPS.has(key)) {
        let next = follow(current[key], previous[key], target[key], rateFor(key), dt);
        if (dt && key.startsWith("foot") && target._gait) next = mix(next, target[key], target._gait.kinematicBlend);
        current[key] = clamp2(next, ...LIMITS[key]);
      }
      for (const key of SHAPES) mouthMix[key] = clamp2(follow(mouthMix[key], previous._mouthMix[key], target._mouthMix[key], 19, dt), 0, 1);
      spring(tips.L, target.earTipL, profile.tipOmega, dt);
      spring(tips.R, target.earTipR, profile.tipOmega * 0.94, dt);
    }
    current.earTipL = tips.L.x;
    current.earTipR = tips.R.x;
    const sum = SHAPES.reduce((total, key) => total + mouthMix[key], 0) || 1;
    for (const key of SHAPES) mouthMix[key] /= sum;
    const mouthShape = SHAPES.reduce((best, key) => mouthMix[key] > mouthMix[best] ? key : best, "smile");
    const closure = Math.max(unit(frame.blink), unit(frame.eyeClose));
    const pose = {
      ...current,
      eyeL: current.eyeL * (1 - closure),
      eyeR: current.eyeR * (1 - closure),
      mouthShape,
      mouthMix: { ...mouthMix },
      gait: target._gait ? { ...target._gait } : null
    };
    previous = target;
    lastT = t;
    counters.steps++;
    lastInput = { t, dt, suppliedDt: rawDt, face, mode: frame.mode ?? "idle", modeT: finite(frame.modeT), gesture: frame.gesture ? { kind: frame.gesture.kind, k: unit(frame.gesture.k) } : null, viewYaw: clamp2(finite(frame.viewYaw), -1, 1), blink: unit(frame.blink), eyeClose: unit(frame.eyeClose), talk: unit(frame.talk) };
    lastPose = pose;
    return { ...pose, mouthMix: { ...pose.mouthMix } };
  }
  function setScheme(id) {
    if (!Object.hasOwn(SCHEMES, id)) throw new RangeError(`Unknown animation scheme: ${id}`);
    schemeId = id;
    return schemeId;
  }
  function inspect() {
    return {
      scheme: schemeId,
      movementGain: movement,
      frame: lastInput ? { ...lastInput, gesture: lastInput.gesture ? { ...lastInput.gesture } : null } : null,
      pose: lastPose ? { ...lastPose, mouthMix: { ...lastPose.mouthMix } } : null,
      target: previous ? { ...Object.fromEntries(Object.keys(BASE).map((key) => [key, previous[key]])), mouthMix: { ...previous._mouthMix } } : null,
      earSprings: { L: { ...tips.L }, R: { ...tips.R } },
      counters: { ...counters },
      expressionIds: [...ANIMATION_CONTRACT.expressionIds],
      gestureIds: [...ANIMATION_CONTRACT.gestureIds],
      clock: ANIMATION_CONTRACT.clock,
      headScaleOwned: false,
      audioAnalysis: false
    };
  }
  return Object.freeze({ step, setScheme, inspect });
}

// runtime/painted-figure.js
var SVG = "http://www.w3.org/2000/svg";
var HTML = "http://www.w3.org/1999/xhtml";
var clamp3 = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
var lerp = (a, b, k) => a + (b - a) * k;
var smooth2 = (a, b, x) => {
  const t = clamp3((x - a) / (b - a));
  return t * t * (3 - 2 * t);
};
var rad = Math.PI / 180;
var keyNames = ["front", "threeQuarter", "side"];
function curve(points, tangents = {}) {
  const p = points.map(([x, y]) => [y, x]);
  const d = p.slice(1).map((v, i) => (v[1] - p[i][1]) / (v[0] - p[i][0]));
  const m = p.map((point, i) => tangents[point[0]] ?? (i === 0 ? d[0] : i === p.length - 1 ? d.at(-1) : d[i - 1] * d[i] <= 0 ? 0 : 2 / (1 / d[i - 1] + 1 / d[i])));
  return (y) => {
    if (y <= p[0][0]) return p[0][1];
    if (y >= p.at(-1)[0]) return p.at(-1)[1];
    let i = 0;
    while (p[i + 1][0] < y) i++;
    const h = p[i + 1][0] - p[i][0], t = (y - p[i][0]) / h, t2 = t * t, t3 = t2 * t;
    return (2 * t3 - 3 * t2 + 1) * p[i][1] + (t3 - 2 * t2 + t) * h * m[i] + (-2 * t3 + 3 * t2) * p[i + 1][1] + (t3 - t2) * h * m[i + 1];
  };
}
function sampleRow(sprite, v) {
  const rows = sprite.contour.rows, t = clamp3(v) * (rows.length - 1);
  const i = Math.min(rows.length - 2, Math.floor(t)), k = t - i;
  return [lerp(rows[i].left, rows[i + 1].left, k), lerp(rows[i].right, rows[i + 1].right, k)];
}
function grid(cols, rows) {
  const count = (cols + 1) * (rows + 1), st = new Float32Array(count * 2), indices = new Uint16Array(cols * rows * 6);
  let j = 0;
  for (let y = 0; y <= rows; y++) for (let x = 0; x <= cols; x++) {
    st[j++] = x / cols;
    st[j++] = y / rows;
  }
  j = 0;
  for (let y = 0; y < rows; y++) for (let x = 0; x < cols; x++) {
    const a = y * (cols + 1) + x, b = a + 1, c = a + cols + 1, d = c + 1;
    indices[j++] = a;
    indices[j++] = b;
    indices[j++] = c;
    indices[j++] = b;
    indices[j++] = d;
    indices[j++] = c;
  }
  return { count, st, indices };
}
function uvGrid(sprite, mesh, { mirror = false, contour = true } = {}) {
  const out = new Float32Array(mesh.count * 2), [au, av, aw, ah] = sprite.uvRect;
  const inset = 4 / sprite.cutSize[0];
  for (let n = 0; n < mesh.count; n++) {
    const u = mesh.st[n * 2], v = mesh.st[n * 2 + 1];
    const sv = contour ? clamp3(v, 3 / sprite.cutSize[1], 1 - 3 / sprite.cutSize[1]) : v;
    const edge = contour ? sampleRow(sprite, sv) : [0, 1];
    const d = contour ? Math.min(inset, (edge[1] - edge[0]) * 0.38) : 0;
    const s = lerp(edge[0] + d, edge[1] - d, mirror ? 1 - u : u);
    out[2 * n] = au + s * aw;
    out[2 * n + 1] = av + sv * ah;
  }
  return out;
}
function rotate(x, y, px, py, degrees) {
  const a = degrees * rad, c = Math.cos(a), s = Math.sin(a), dx = x - px, dy = y - py;
  return [px + dx * c - dy * s, py + dx * s + dy * c];
}
function bezier(values, t) {
  const s = 1 - t;
  return s * s * s * values[0] + 3 * s * s * t * values[1] + 3 * s * t * t * values[2] + t * t * t * values[3];
}
function earProfile(v, root, tip) {
  if (v < 0.11) return Math.max(3e-3, root * Math.sqrt(Math.max(0, 1 - (1 - v / 0.11) ** 2)));
  if (v > 0.78) return Math.max(3e-3, tip * Math.sqrt(Math.max(0, 1 - ((v - 0.78) / 0.22) ** 2)));
  return lerp(root, tip, smooth2(0.11, 0.78, v));
}
function interpolateKey(q) {
  return q < 0.6 ? { a: 0, b: 1, k: smooth2(0, 0.6, q) } : { a: 1, b: 2, k: smooth2(0.6, 1, q) };
}
async function createPaintedFigure(base, opts) {
  const model = opts.model;
  if (model?.format !== "maodou-painted-mesh" || !model.art?.sprites || !model.approvedFront?.contour) {
    throw new Error("Maodou requires its complete model.json with the approved front contour and painted atlas metadata.");
  }
  const doc = opts.host?.root?.ownerDocument ?? document;
  const canvas = doc.createElementNS(HTML, "canvas");
  const view = model.view ?? [-36, -28, 292, 282], viewW = view[2] - view[0], viewH = view[3] - view[1];
  canvas.width = model.renderEdge ?? 512;
  canvas.height = Math.round(canvas.width * viewH / viewW);
  canvas.setAttribute("aria-label", "\u5F02\u8272\u5927\u8033\u5E3D\u515C");
  Object.assign(canvas.style, { width: "100%", height: "100%", display: "block", pointerEvents: "none" });
  const foreign = doc.createElementNS(SVG, "foreignObject");
  for (const [key, value] of Object.entries({ x: view[0], y: view[1], width: viewW, height: viewH })) foreign.setAttribute(key, value);
  foreign.setAttribute("pointer-events", "none");
  foreign.appendChild(canvas);
  let errors = [], lastFrame = null, pose = null, lastYaw = 0, disposed = false, renderCount = 0, scheme = opts.scheme?.includes?.("lively") ? "lively" : "gentle";
  const animator = createAnimator({ scheme });
  const renderer = createAtlasRenderer(canvas, {
    view,
    maxEdge: model.renderEdge ?? 512,
    outline: model.outline,
    // A native SVG foreignObject may composite between animation callbacks.
    preserveDrawingBuffer: true,
    onError: (e) => {
      errors.push(String(e?.message ?? e));
      if (errors.length > 20) errors.shift();
    }
  });
  try {
    renderer.setAtlas(await opts.loadImage(opts.asset(model.art.atlas.file)), { version: model.art.atlas.sha256 });
  } catch (e) {
    renderer.dispose();
    throw e;
  }
  const art = model.art.sprites, parts = [], byId = /* @__PURE__ */ new Map();
  function make(id, spriteId, mesh, z, options = {}) {
    const p = {
      id,
      xy: new Float32Array(mesh.count * 2),
      uv: uvGrid(art[spriteId], mesh, { contour: options.contour !== false, mirror: options.mirror }),
      uv2: new Float32Array(mesh.count * 2),
      mix: new Float32Array(mesh.count),
      vertexAlpha: new Float32Array(mesh.count).fill(1),
      rootUV: new Float32Array(mesh.count * 2),
      rootUV2: new Float32Array(mesh.count * 2),
      rootMix: new Float32Array(mesh.count),
      rootWeight: new Float32Array(mesh.count),
      indices: mesh.indices,
      z,
      clip: options.clip,
      alpha: 1
    };
    p.uv2.set(p.uv);
    parts.push(p);
    byId.set(id, { p, mesh, spriteId });
    return p;
  }
  const headMesh = grid(12, 64), torsoMesh = grid(10, 40), earMesh = grid(12, 48), limbMesh = grid(5, 12), faceMesh = grid(1, 1), lidMesh = grid(12, 2);
  const tail = make("tail", "tail", limbMesh, 0);
  const earL = make("earL", "ear.front", earMesh, 2, { mirror: true }), earR = make("earR", "ear.front", earMesh, 2);
  const footL = make("footL", "foot.left", limbMesh, 5), footR = make("footR", "foot.right", limbMesh, 5);
  const armL = make("armL", "arm.left", limbMesh, 9), armR = make("armR", "arm.right", limbMesh, 9);
  const body = make("body", "torso.front", torsoMesh, 12), head = make("head", "head.front", headMesh, 18);
  const faceClip = { mask: "face", mode: "inside" };
  const features = {};
  for (const side of ["L", "R"]) {
    features["blush" + side] = make("blush" + side, "blush", faceMesh, 20, { contour: false, clip: faceClip });
    features["eye" + side] = make("eye" + side, "eye.open", faceMesh, 23, { contour: false, clip: faceClip });
    features["lid" + side] = make("lid" + side, "eye.closed", lidMesh, 24, { contour: false, clip: faceClip });
    features["brow" + side] = make("brow" + side, side === "L" ? "brow.left" : "brow.right", faceMesh, 22, { contour: false, clip: faceClip });
    features["tear" + side] = make("tear" + side, "tear", faceMesh, 25, { contour: false, clip: faceClip });
  }
  features.mouth = make("mouth", "mouth.smile", faceMesh, 24, { contour: false, clip: faceClip });
  const frontL = make("earFrontL", "ear.front", earMesh, 32, { mirror: true, clip: { mask: "solid", mode: "inside" } });
  const frontR = make("earFrontR", "ear.front", earMesh, 32, { clip: { mask: "solid", mode: "inside" } });
  const limbFront = {};
  for (const [id, sprite, z] of [["armL", "arm.left", 15], ["armR", "arm.right", 15], ["footL", "foot.left", 14], ["footR", "foot.right", 14]]) {
    limbFront[id] = make(id + "Front", sprite, limbMesh, z, { clip: { mask: "torso", mode: "inside" } });
  }
  for (const [front, back] of [[frontL, earL], [frontR, earR], ...Object.entries(limbFront).map(([id, p]) => [p, byId.get(id).p])]) {
    for (const key of ["xy", "uv", "uv2", "mix", "rootUV", "rootUV2", "rootMix", "rootWeight"]) front[key] = back[key];
  }
  renderer.setScene({ parts, masks: [
    { id: "face", parts: ["head"] },
    { id: "solid", parts: ["head", "body", "armL", "armR"], supportThreshold: 0.06 },
    { id: "torso", parts: ["body"], supportThreshold: 0.06 }
  ] });
  const headUV = keyNames.map((k) => uvGrid(art["head." + k], headMesh));
  const bodyUV = keyNames.map((k) => uvGrid(art["torso." + k], torsoMesh));
  const headLeftUV = keyNames.map((k, i) => i ? uvGrid(art["head." + k], headMesh, { mirror: true }) : headUV[0]);
  const bodyLeftUV = keyNames.map((k, i) => i ? uvGrid(art["torso." + k], torsoMesh, { mirror: true }) : bodyUV[0]);
  const earUV = {
    L: [uvGrid(art["ear.front"], earMesh, { mirror: true }), uvGrid(art["ear.outer"], earMesh, { mirror: true })],
    R: [uvGrid(art["ear.front"], earMesh), uvGrid(art["ear.outer"], earMesh)]
  };
  const featureUV = {};
  for (const id of ["eye.open", "eye.closed", "eye.happy", "mouth.smile", "mouth.open", "mouth.o", "mouth.sad"]) featureUV[id] = uvGrid(art[id], faceMesh, { contour: false });
  const approved = model.approvedFront, reg = approved.registration;
  const leftCurve = curve(approved.contour.left, { 320: -0.87856 }), rightCurve = curve(approved.contour.right, { 320: 0.86825 });
  const earRows = approved.ears.rows;
  function restEar(side, u, v) {
    const t = clamp3(v) * (earRows.length - 1), i = Math.min(earRows.length - 2, Math.floor(t)), k = t - i;
    const lo = lerp(earRows[i][side][0], earRows[i + 1][side][0], k), hi = lerp(earRows[i][side][1], earRows[i + 1][side][1], k);
    const py = lerp(earRows[i].y, earRows[i + 1].y, k);
    return [reg.targetCenterX + (lerp(lo, hi, u) - reg.sourceCenterX) * reg.scale, reg.targetTopY + (py - reg.sourceTopY) * reg.scale];
  }
  const restEarWidths = Object.fromEntries(["L", "R"].map((side) => [
    side,
    Array.from({ length: 49 }, (_, row) => restEar(side, 1, row / 48)[0] - restEar(side, 0, row / 48)[0])
  ]));
  const headKeys = keyNames.map((key, ki) => {
    const pos = new Float32Array(headMesh.count * 2), spr = art["head." + key], box = model.head[key];
    for (let n = 0; n < headMesh.count; n++) {
      const u = headMesh.st[n * 2], v = headMesh.st[n * 2 + 1];
      if (ki === 0) {
        const py = reg.sourceTopY + v * 565, px = lerp(leftCurve(py), rightCurve(py), u);
        pos[n * 2] = reg.targetCenterX + (px - reg.sourceCenterX) * reg.scale;
        pos[n * 2 + 1] = reg.targetTopY + (py - reg.sourceTopY) * reg.scale;
      } else {
        const edge = sampleRow(spr, v);
        const s = v === 0 || v === 1 ? (edge[0] + edge[1]) * 0.5 : lerp(edge[0], edge[1], u);
        pos[n * 2] = box[0] + s * box[2];
        pos[n * 2 + 1] = box[1] + v * box[3];
      }
    }
    return pos;
  });
  const torsoKeys = keyNames.map((key) => {
    const pos = new Float32Array(torsoMesh.count * 2), spr = art["torso." + key], box = model.torso[key];
    for (let n = 0; n < torsoMesh.count; n++) {
      const u = torsoMesh.st[n * 2], v = torsoMesh.st[n * 2 + 1], edge = sampleRow(spr, v);
      pos[n * 2] = box[0] + lerp(edge[0], edge[1], u) * box[2];
      pos[n * 2 + 1] = box[1] + v * box[3];
    }
    return pos;
  });
  function leftFacingKeys(keys, cols) {
    return keys.map((key, index) => {
      if (!index) return key;
      const out = new Float32Array(key.length), rowWidth = cols + 1;
      for (let n = 0; n < key.length / 2; n++) {
        const row = Math.floor(n / rowWidth), col = n % rowWidth, source = (row * rowWidth + cols - col) * 2;
        out[n * 2] = 256 - key[source];
        out[n * 2 + 1] = key[source + 1];
      }
      return out;
    });
  }
  const headLeftKeys = leftFacingKeys(headKeys, 12), torsoLeftKeys = leftFacingKeys(torsoKeys, 10);
  const currentHeadRaw = new Float32Array(headMesh.count * 2);
  const projectedHeadKeys = [currentHeadRaw, currentHeadRaw, currentHeadRaw];
  const earRootCoordinates = { L: new Float32Array(earMesh.count * 2), R: new Float32Array(earMesh.count * 2) };
  let extent = [-22, 20, 278, 257], hits = [[128, 96, 66], [128, 197, 45], [38, 180, 29], [218, 180, 29]], anchors = { gaze: [128, 116], bubble: [128, 16], z: [180, 40], hearts: [86, 170, 30], tears: [[87, 128], [169, 128]] };
  let occlusion = { left: 0, right: 0 }, headBounds = [54, 22, 202, 164], faceCenters = {};
  function setMix(p, uv1, uv2, k) {
    p.uv.set(uv1);
    p.uv2.set(uv2 ?? uv1);
    p.mix.fill(k);
  }
  function transformHead(x, y) {
    const q = pose ?? {}, sit = clamp3(lastFrame?.sit ?? 0), low = lastFrame?.low ?? 0;
    const restY = (q.bodyY ?? 0) + (q.headY ?? 0) + sit * 14 + Math.min(10, low * 0.32);
    y += Math.max(0, 164 - y) * (1 - (model.headHeightScale ?? 1));
    return rotate(x, y + restY, 128, 153 + restY, (q.headTilt ?? 0) + (q.bodyTilt ?? 0) * 0.35);
  }
  function transformBody(x, y) {
    const sit = clamp3(lastFrame?.sit ?? 0), low = lastFrame?.low ?? 0;
    const sx = (pose.bodySX ?? 1) * (1 + sit * 0.04), sy = (pose.bodySY ?? 1) * (1 - sit * 0.19);
    const X = 128 + (x - 128) * sx, Y = 240 + (y - 240) * sy + (pose.bodyY ?? 0) + Math.min(8, low * 0.23);
    return rotate(X, Y, 128, 238, pose.bodyTilt ?? 0);
  }
  function morph(p, keys, uvs, state, transform) {
    setMix(p, uvs[state.a], uvs[state.b], state.k);
    for (let n = 0; n < p.xy.length; n += 2) {
      let x = lerp(keys[state.a][n], keys[state.b][n], state.k), y = lerp(keys[state.a][n + 1], keys[state.b][n + 1], state.k);
      if (p === head) {
        currentHeadRaw[n] = x;
        currentHeadRaw[n + 1] = y;
      }
      const out = transform(x, y);
      p.xy[n] = out[0];
      p.xy[n + 1] = out[1];
    }
  }
  function rootMaterial(p, n, x, y, weight, keys, uvs, state, cols = 12, rows = 64) {
    const a = keys[state.a], b = keys[state.b], stride = cols + 1;
    const top = lerp(a[1], b[1], state.k), end = rows * stride * 2;
    const bottom = lerp(a[end + 1], b[end + 1], state.k);
    const row = clamp3((y - top) / (bottom - top)) * rows, r0 = Math.min(rows - 1, Math.floor(row)), fr = row - r0;
    const edge = (col) => {
      const i = (r0 * stride + col) * 2, j = i + stride * 2;
      return lerp(lerp(a[i], a[j], fr), lerp(b[i], b[j], fr), state.k);
    };
    const left = edge(0), right = edge(cols), u = clamp3((x - left) / Math.max(1e-4, right - left));
    const column = u * cols, c0 = Math.min(cols - 1, Math.floor(column)), fc = column - c0;
    for (const [dest, src] of [[p.rootUV, uvs[state.a]], [p.rootUV2, uvs[state.b]]]) {
      const i = (r0 * stride + c0) * 2, j = i + stride * 2;
      for (let k = 0; k < 2; k++) dest[n * 2 + k] = lerp(lerp(src[i + k], src[i + 2 + k], fc), lerp(src[j + k], src[j + 2 + k], fc), fr);
    }
    p.rootMix[n] = state.k;
    p.rootWeight[n] = weight;
  }
  function spriteBox(p, mesh, spriteId, box, { angle = 0, pivot = null, transform = null, alpha = 1, mirror = false, material = null } = {}) {
    const spr = art[spriteId];
    for (let n = 0; n < mesh.count; n++) {
      const u = mesh.st[n * 2], v = mesh.st[n * 2 + 1], edge = sampleRow(spr, v);
      let x = box[0] + lerp(edge[0], edge[1], u) * box[2], y = box[1] + v * box[3];
      if (mirror) x = 256 - x;
      if (angle) [x, y] = rotate(x, y, pivot?.[0] ?? box[0] + box[2] / 2, pivot?.[1] ?? box[1] + box[3] / 2, angle);
      if (material) material(n, x, y);
      if (transform) [x, y] = transform(x, y);
      p.xy[n * 2] = x;
      p.xy[n * 2 + 1] = y;
    }
    p.vertexAlpha.fill(clamp3(alpha));
  }
  function quad(p, cx, cy, w, h, angle = 0, alpha = 1) {
    for (let n = 0; n < 4; n++) {
      let x = cx + (faceMesh.st[n * 2] - 0.5) * w, y = cy + (faceMesh.st[n * 2 + 1] - 0.5) * h;
      if (angle) [x, y] = rotate(x, y, cx, cy, angle);
      [x, y] = transformHead(x, y);
      p.xy[n * 2] = x;
      p.xy[n * 2 + 1] = y;
    }
    p.vertexAlpha.fill(clamp3(alpha));
  }
  function closedLid(p, cx, cy, width, happy, angle, alpha) {
    const mid = model.featureProfiles.closedEyeMidline, center = mid[6], curvature = lerp(6, -11, happy);
    for (let n = 0; n < lidMesh.count; n++) {
      const u = lidMesh.st[n * 2], v = lidMesh.st[n * 2 + 1], column = Math.round(u * 12), sourceCenter = mid[column];
      let x = cx + (u - 0.5) * width, y = cy + (v - sourceCenter) * 5 + (sourceCenter - center) * curvature;
      if (angle) [x, y] = rotate(x, y, cx, cy, angle);
      [x, y] = transformHead(x, y);
      p.xy[n * 2] = x;
      p.xy[n * 2 + 1] = y;
    }
    p.vertexAlpha.fill(clamp3(alpha));
  }
  function fairEarShoulder(rows, isLeft, q, keys, state) {
    const gain = smooth2(0, 0.1, q) * (1 - smooth2(0.42, 0.6, q));
    if (!gain) return;
    const a = keys[state.a], b = keys[state.b], stride = 13, sign = isLeft ? -1 : 1, col = isLeft ? 0 : 12;
    const top = lerp(a[1], b[1], state.k), bottom = lerp(a[64 * stride * 2 + 1], b[64 * stride * 2 + 1], state.k);
    const headAt = (y) => {
      const t = clamp3((y - top) / (bottom - top)) * 64, i = Math.min(63, Math.floor(t)), k = t - i;
      const ix = (i * stride + col) * 2, jx = ix + stride * 2;
      return sign * lerp(lerp(a[ix], a[jx], k), lerp(b[ix], b[jx], k), state.k);
    };
    const free = rows.map((r) => ({ y: r.rawY, out: sign * r.rawX + r.width * 0.5 }));
    const earAt = (y) => {
      if (y <= free[0].y) return free[0].out;
      if (y >= free.at(-1).y) return free.at(-1).out;
      let i = 0;
      while (free[i + 1].y < y) i++;
      return lerp(free[i].out, free[i + 1].out, (y - free[i].y) / (free[i + 1].y - free[i].y));
    };
    const union = (y) => Math.max(headAt(y), earAt(y));
    const y0 = lerp(top, bottom, 0.18), y1 = lerp(top, bottom, 0.38), h = y1 - y0, u0 = union(y0), u1 = union(y1), secant = (u1 - u0) / h;
    const tangent = (y) => {
      const m = (union(y + 1) - union(y - 1)) * 0.5;
      return m * secant > 0 ? Math.sign(m) * Math.min(Math.abs(m), 3 * Math.abs(secant)) : 0;
    };
    const m0 = tangent(y0), m1 = tangent(y1), buffer = rows[2].rawY - rows[0].rawY;
    const hermite = (t) => {
      const t2 = t * t, t3 = t2 * t;
      return (2 * t3 - 3 * t2 + 1) * u0 + (t3 - 2 * t2 + t) * h * m0 + (-2 * t3 + 3 * t2) * u1 + (t3 - t2) * h * m1;
    };
    for (let row = 0; row <= 64; row++) {
      const first = row * stride * 2, y = currentHeadRaw[first + 1];
      if (y < y0 || y > y1) continue;
      const delta = Math.min(0, hermite((y - y0) / h) - headAt(y)) * gain;
      if (!delta) continue;
      for (let c = 0; c <= 12; c++) {
        const n = first + c * 2, weight = isLeft ? 1 - c / 12 : c / 12;
        currentHeadRaw[n] += sign * delta * weight;
        const out = transformHead(currentHeadRaw[n], currentHeadRaw[n + 1]);
        head.xy[n] = out[0];
        head.xy[n + 1] = out[1];
      }
    }
    for (const row of rows) {
      const y = row.rawY, current = sign * row.rawX + row.width * 0.5;
      let target = current;
      if (y >= y0 && y <= y1) {
        target = hermite((y - y0) / h);
      } else if (y >= y0 - buffer && y < y0) {
        target = current + smooth2(y0 - buffer, y0, y) * Math.max(0, headAt(y) - current);
      } else if (y > y1 && y <= y1 + buffer) {
        target = current + (1 - smooth2(y1, y1 + buffer, y)) * Math.max(0, headAt(y) - current);
      }
      const delta = (target - current) * gain;
      row.rawX += sign * delta * 0.5;
      row.width += delta;
    }
  }
  function ears(q, sign, state) {
    const near45 = [95, 107, 92, 67], near75 = [135, 130, 103, 82];
    const far45 = [175, 203, 216, 223], far75 = [166, 181, 194, 201];
    const keys = sign < 0 ? headLeftKeys : headKeys, uvs = sign < 0 ? headLeftUV : headUV;
    const rootTurn = smooth2(0.05, 0.55, q);
    for (const side of ["L", "R"]) {
      const isLeft = side === "L", near = sign >= 0 ? isLeft : !isLeft, p = isLeft ? earL : earR, over = isLeft ? frontL : frontR;
      const mid = near ? near45 : far45.map((x) => 256 - x), end = near ? near75 : far75.map((x) => 256 - x);
      const centers = [mid, mid, end], mix2 = smooth2(0.05, 0.57, q) * (near ? 1 : 0.12);
      setMix(p, earUV[side][0], earUV[side][1], mix2);
      const widths = near ? [72, 82, 96] : [72, 51, 35], heights = near ? [198, 195, 195] : [198, 185, 181];
      const width = lerp(widths[state.a], widths[state.b], state.k), height = lerp(heights[state.a], heights[state.b], state.k);
      const lift = pose["earLift" + side] ?? 0, inward = pose["earIn" + side] ?? 0, curl = pose["earCurl" + side] ?? 0, tip = pose["earTip" + side] ?? 0;
      const raise = clamp3(pose["earRaise" + side] ?? 0), spread = clamp3(pose["earSpread" + side] ?? 0, -1, 1);
      const ss = isLeft ? 1 : -1;
      const rows = [];
      for (let row = 0; row <= 48; row++) {
        const v = row / 48, profile = earProfile(v, lerp(0.48, 0.54, mix2), lerp(0.8, 0.88, mix2));
        let center = lerp(bezier(centers[state.a], v), bezier(centers[state.b], v), state.k);
        if (!isLeft) center = 256 - center;
        let rowWidth = width * profile, y = 47 + v * height;
        if (state.a === 0) {
          const rest = restEar(side, 0.5, v), target = bezier(centers[1], v);
          center = lerp(rest[0], isLeft ? target : 256 - target, state.k);
          y = lerp(rest[1], 47 + v * heights[1], state.k);
          rowWidth = lerp(restEarWidths[side][row], widths[1] * profile, state.k);
        }
        const delay = v * v * (3 - 2 * v);
        center += ss * (inward * delay + Math.sin(curl * rad) * v * v * 36 - tip * v * v);
        y -= lift * v * v;
        y += (pose.bodyY ?? 0) * v * 0.15;
        const angle = ss * (raise * 69 + spread * 9) * smooth2(0.015, 0.47, v) * rad;
        rows.push({ rawX: center, rawY: y, x: center, y, width: rowWidth, angle });
      }
      fairEarShoulder(rows, isLeft, q, keys, state);
      for (let row = 0; row < rows.length; row++) {
        const current = rows[row], previous = rows[row - 1];
        current.x = current.rawX;
        current.y = current.rawY;
        if (previous) {
          const theta = (current.angle + previous.angle) * 0.5, dx = current.rawX - previous.rawX, stepY = current.rawY - previous.rawY;
          current.x = previous.x + dx * Math.cos(theta) - stepY * Math.sin(theta);
          current.y = previous.y + dx * Math.sin(theta) + stepY * Math.cos(theta);
        }
      }
      let coverage = 0;
      for (let n = 0; n < earMesh.count; n++) {
        const u = earMesh.st[n * 2], v = earMesh.st[n * 2 + 1];
        const r = rows[Math.round(v * 48)], offset = (u - 0.5) * r.width;
        let x = r.x + offset * Math.cos(r.angle), y = r.y + offset * Math.sin(r.angle);
        y += offset * ss * Math.sin(curl * rad) * v * 0.12;
        const rootWeight = 1 - smooth2(lerp(0.16, 0.08, rootTurn), lerp(0.42, near ? 0.3 : 0.28, rootTurn), v);
        earRootCoordinates[side][n * 2] = x;
        earRootCoordinates[side][n * 2 + 1] = y;
        p.rootWeight[n] = rootWeight;
        [x, y] = transformHead(x, y);
        p.xy[n * 2] = x;
        p.xy[n * 2 + 1] = y;
        const turnProgress = near ? smooth2(0.025, 0.44, q) : 0;
        const poseProgress = smooth2(3, 27, inward) * 0.9;
        const progress = Math.max(turnProgress, poseProgress);
        const rollU = isLeft ? u : 1 - u;
        const field = (1 - smooth2(progress * 1.13 - 0.11, progress * 1.13 + 0.11, rollU)) * smooth2(0.025, 0.36, v) * smooth2(0, 0.035, progress);
        over.vertexAlpha[n] = field;
        coverage += field;
      }
      occlusion[isLeft ? "left" : "right"] = coverage / earMesh.count;
    }
    for (const side of ["L", "R"]) {
      const p = side === "L" ? earL : earR, raw = earRootCoordinates[side];
      for (let n = 0; n < earMesh.count; n++) rootMaterial(p, n, raw[n * 2], raw[n * 2 + 1], p.rootWeight[n], projectedHeadKeys, uvs, state);
    }
  }
  function face(q, sign, state) {
    const proj = {
      near: [[0.23, 0.657, 1], [0.58, 0.655, 0.91], [0.825, 0.66, 0.61]],
      far: [[0.77, 0.657, 1], [0.952, 0.627, 0.43], [1.145, 0.62, 0.24]],
      browNear: [[0.293, 0.227, 1], [0.612, 0.24, 0.84], [0.802, 0.25, 0.66]],
      browFar: [[0.71, 0.227, 1], [0.91, 0.21, 0.58], [1.12, 0.21, 0.32]],
      mouth: [[0.5, 0.784, 1], [0.823, 0.775, 0.84], [0.965, 0.768, 0.52]]
    };
    const hboxes = keyNames.map((k) => model.head[k]);
    const box = hboxes[0].map((_, i) => lerp(hboxes[state.a][i], hboxes[state.b][i], state.k));
    function point(rows) {
      const uv = rows[0].map((_, i) => lerp(rows[state.a][i], rows[state.b][i], state.k));
      let x = box[0] + uv[0] * box[2], y = box[1] + uv[1] * box[3];
      if (sign < 0) x = 256 - x;
      return [x, y, uv[2]];
    }
    const gaze = lastFrame.lookScreen ?? [0, 0], lookX = clamp3(gaze[0] / 5, -1, 1) * (1 - q * 0.65) * 2.5, lookY = clamp3(gaze[1] / 5, -1, 1) * 1.8;
    for (const side of ["L", "R"]) {
      const near = sign >= 0 ? side === "L" : side === "R", p = point(proj[near ? "near" : "far"]);
      const open = clamp3(pose["eye" + side] ?? 1, 0, 1.15), happy = clamp3(pose["happy" + side] ?? 0);
      const wide = 22 * p[2] * (1 + 0.07 * Math.max(0, open - 1)), height = Math.max(1, 36.8 * open);
      const alpha = smooth2(0.28, 0.34, open), angle = pose["eyeTilt" + side] ?? 0;
      quad(features["eye" + side], p[0] + lookX, p[1] + lookY, wide, height, angle, alpha);
      closedLid(features["lid" + side], p[0] + lookX, p[1] + lookY + 1, wide * 1.06, happy, angle, 1 - alpha);
      const brow = point(proj[near ? "browNear" : "browFar"]);
      quad(features["brow" + side], brow[0], brow[1] + (pose.browY ?? 0), 10.7 * brow[2], 8.1, (side === "L" ? 1 : -1) * (pose.browTilt ?? 0));
      quad(features["blush" + side], p[0] + (side === "L" ? -3 : 3), p[1] + 22, 36 * p[2], 25, 0, (pose.blush ?? 0) * 0.75);
      const drop = (lastFrame.t * 0.72 + (side === "L" ? 0 : 0.48)) % 1;
      quad(features["tear" + side], p[0] + (side === "L" ? -7 : 7) * p[2], p[1] + 19 + drop * 14, 5.1 * p[2], 7.8, 0, (pose.tear ?? 0) * Math.sin(drop * Math.PI));
      faceCenters[side] = transformHead(p[0] + lookX, p[1] + lookY);
    }
    const m = point(proj.mouth), mix2 = pose.mouthMix ?? { [pose.mouthShape ?? "smile"]: 1 };
    const entries = Object.entries(mix2).filter(([k]) => featureUV["mouth." + k]).sort((a, b) => b[1] - a[1]);
    const first = entries[0] ?? ["smile", 1], second = entries[1] ?? first;
    setMix(features.mouth, featureUV["mouth." + first[0]], featureUV["mouth." + second[0]], second === first ? 0 : second[1] / Math.max(1e-5, first[1] + second[1]));
    quad(features.mouth, m[0] + lookX * 0.25, m[1], (pose.mouthW ?? 9) * m[2], pose.mouthH ?? 2.4);
  }
  function boundsOf(p) {
    const b = [Infinity, Infinity, -Infinity, -Infinity];
    for (let n = 0; n < p.xy.length; n += 2) {
      b[0] = Math.min(b[0], p.xy[n]);
      b[1] = Math.min(b[1], p.xy[n + 1]);
      b[2] = Math.max(b[2], p.xy[n]);
      b[3] = Math.max(b[3], p.xy[n + 1]);
    }
    return b;
  }
  function meshHealth() {
    const result = {};
    for (const p of [head, body, earL, earR, armL, armR, footL, footR]) {
      let minArea = Infinity, negativeTriangles = 0;
      const negativeSamples = [];
      for (let i = 0; i < p.indices.length; i += 3) {
        const a = p.indices[i] * 2, b = p.indices[i + 1] * 2, c = p.indices[i + 2] * 2;
        const area = ((p.xy[b] - p.xy[a]) * (p.xy[c + 1] - p.xy[a + 1]) - (p.xy[b + 1] - p.xy[a + 1]) * (p.xy[c] - p.xy[a])) * 0.5;
        minArea = Math.min(minArea, area);
        if (area < -1e-5) {
          negativeTriangles++;
          if (negativeSamples.length < 3) negativeSamples.push({ triangle: i / 3, area, indices: [a / 2, b / 2, c / 2], points: [a, b, c].map((n) => [p.xy[n], p.xy[n + 1]]) });
        }
      }
      result[p.id] = { bounds: boundsOf(p), minArea, negativeTriangles, negativeSamples };
    }
    return result;
  }
  function inspectLimbs() {
    const nearSide = lastYaw < 0 ? "R" : "L", limbs = {};
    for (const p of [armL, armR, footL, footR]) {
      const bounds = boundsOf(p), fg = limbFront[p.id];
      let sum = 0, peak = 0;
      for (const alpha of fg.vertexAlpha) {
        sum += alpha;
        peak = Math.max(peak, alpha);
      }
      const isFoot = p.id.startsWith("foot");
      limbs[p.id] = {
        bounds,
        center: [(bounds[0] + bounds[2]) / 2, (bounds[1] + bounds[3]) / 2],
        baseZ: isFoot ? p.id.endsWith(nearSide) ? 6 : 5 : 9,
        foregroundZ: fg.z,
        foregroundMean: sum / fg.vertexAlpha.length,
        foregroundPeak: peak
      };
    }
    return {
      nearSide,
      hipGap: lerp(19, 4, smooth2(0.08, 0.9, Math.abs(lastYaw))),
      footSeparationX: limbs.footR.center[0] - limbs.footL.center[0],
      parts: limbs
    };
  }
  function updateBounds() {
    const bs = [head, body, earL, earR, armL, armR, footL, footR, ...Math.abs(lastYaw) > 0.06 ? [tail] : []].map(boundsOf);
    extent = [Math.min(...bs.map((b) => b[0])) - 0.7, Math.min(...bs.map((b) => b[1])) - 0.7, Math.max(...bs.map((b) => b[2])) + 0.7, Math.max(...bs.map((b) => b[3])) + 0.7];
    headBounds = bs[0];
    const hx = (headBounds[0] + headBounds[2]) / 2, hy = (headBounds[1] + headBounds[3]) / 2;
    hits = [[hx, hy, Math.min(headBounds[2] - headBounds[0], headBounds[3] - headBounds[1]) * 0.43], [128, 200, 39]];
    for (const p of [earL, earR]) for (const v of [0.42, 0.72, 0.9]) {
      const row = Math.round(v * 48), n = (row * 13 + 6) * 2;
      hits.push([p.xy[n], p.xy[n + 1], 17]);
    }
    const left = faceCenters.L ?? [86, 117], right = faceCenters.R ?? [170, 117];
    anchors = {
      gaze: [(left[0] + right[0]) / 2, (left[1] + right[1]) / 2],
      bubble: [hx, Math.max(view[1] + 4, headBounds[1] - 7)],
      z: [headBounds[2] - 9, headBounds[1] + 14],
      hearts: [hx - 30, hx + 30, headBounds[1] + 5],
      tears: [[left[0], left[1] + 16], [right[0], right[1] + 16]],
      tear: [right[0], right[1] + 16]
    };
  }
  const figure = {
    colors: { z: "#65bcc9" },
    gestures: ["nod", "shake", "spin", "wave", "bow", "shiver", "flap", ...CUSTOM_MOTION_IDS],
    get extent() {
      return extent;
    },
    get hits() {
      return hits;
    },
    get anchors() {
      return anchors;
    },
    groupTilt(mode, tilt, lean) {
      return mode === "drag" || mode === "air" ? tilt + lean : clamp3(tilt + lean, -15, 15);
    },
    draw(group, _face, frame) {
      if (disposed) return;
      if (foreign.parentNode !== group) group.appendChild(foreign);
      lastFrame = frame;
      pose = animator.step(frame);
      lastYaw = clamp3((frame.viewYaw ?? 0) + (pose.yawOffset ?? 0), -1, 1);
      const q = Math.abs(lastYaw), sign = lastYaw < 0 ? -1 : 1, state = interpolateKey(q);
      morph(body, sign < 0 ? torsoLeftKeys : torsoKeys, sign < 0 ? bodyLeftUV : bodyUV, state, transformBody);
      morph(head, sign < 0 ? headLeftKeys : headKeys, sign < 0 ? headLeftUV : headUV, state, transformHead);
      ears(q, sign, state);
      const handIn = pose.handIn ?? 0;
      const armKeys = { near: [[68, 171, 38, 34], [101, 172, 31, 38], [115, 173, 26, 39]], far: [[150, 171, 38, 34], [153, 171, 27, 35], [149, 171, 19, 35]] };
      const turn = smooth2(0.03, 0.48, q), bodyKeys = sign < 0 ? torsoLeftKeys : torsoKeys, bodyUVs = sign < 0 ? bodyLeftUV : bodyUV;
      for (const side of ["L", "R"]) {
        const isLeft = side === "L", near = sign >= 0 ? isLeft : !isLeft, rows = armKeys[near ? "near" : "far"];
        const box = rows[0].map((_, i) => lerp(rows[state.a][i], rows[state.b][i], state.k));
        if (sign < 0) box[0] = 256 - box[0] - box[2];
        box[0] += (isLeft ? 1 : -1) * handIn;
        const pivot = [isLeft ? box[0] + box[2] - 3 : box[0] + 3, box[1] + 2];
        const arm = isLeft ? armL : armR, armOver = limbFront["arm" + side];
        spriteBox(arm, limbMesh, isLeft ? "arm.left" : "arm.right", box, {
          angle: pose["arm" + side] ?? 0,
          pivot,
          transform: transformBody,
          material: (n, x, y) => rootMaterial(arm, n, x, y, 1 - smooth2(0.05, 0.46, limbMesh.st[n * 2 + 1]), bodyKeys, bodyUVs, state, 10, 40)
        });
        for (let n = 0; n < limbMesh.count; n++) armOver.vertexAlpha[n] = (near ? turn : 0) * smooth2(0.02, 0.34, limbMesh.st[n * 2 + 1]);
      }
      const footW = 26 - q * 5, gap = lerp(19, 4, smooth2(0.08, 0.9, q)), footShift = sign * q * 6;
      for (const side of ["L", "R"]) {
        const left = side === "L", near = sign >= 0 ? left : !left, foot = left ? footL : footR;
        const fx = pose["footX" + side] ?? 0, lift = pose["footLift" + side] ?? 0;
        const box = [128 + (left ? -gap : gap) - footW / 2 + footShift + fx, 231 - lift, footW, 25];
        const angle = pose.gait ? -fx * 0.3 * smooth2(0, 3, lift) : (left ? -3 : 3) * (1 - q);
        spriteBox(foot, limbMesh, left ? "foot.left" : "foot.right", box, { angle, pivot: [box[0] + footW * 0.5, box[1] + 25] });
        renderer.updatePart(foot.id, { z: near ? 6 : 5 });
        for (let n = 0; n < limbMesh.count; n++) limbFront["foot" + side].vertexAlpha[n] = (near ? turn : 0) * smooth2(0.05, 0.38, limbMesh.st[n * 2 + 1]);
      }
      spriteBox(tail, limbMesh, "tail", [128 - sign * (39 + q * 5) - 14, 207, 28, 25], { angle: pose.tail ?? 0, transform: transformBody, alpha: smooth2(0.04, 0.3, q) });
      face(q, sign, state);
      updateBounds();
      renderer.render();
      renderCount++;
    },
    setScheme(id) {
      scheme = String(id).includes("lively") ? "lively" : "gentle";
      animator.setScheme(scheme);
    },
    setRenderEdge(edge) {
      const e = clamp3(Math.round(edge), 256, 640);
      renderer.resize(e, Math.round(e * viewH / viewW), { maxEdge: e });
    },
    inspect() {
      return {
        format: model.format,
        version: model.version,
        scheme,
        renderCount,
        disposed,
        viewYaw: lastYaw,
        pose: pose ? { ...pose } : null,
        occlusion: { ...occlusion },
        extent: extent.slice(),
        headBounds: headBounds.slice(),
        faceCenters: { ...faceCenters },
        approvedFrontSource: model.approvedFront.source.sha256,
        meshHealth: meshHealth(),
        limbs: inspectLimbs(),
        errors: errors.slice(),
        renderer: renderer.inspect(),
        animator: animator.inspect()
      };
    },
    dispose() {
      if (disposed) return;
      disposed = true;
      renderer.dispose();
      foreign.remove();
    }
  };
  return figure;
}

// pack/figure.js
async function createMaodouBody(base, opts) {
  const kit = adaptNativeKit(opts.kit);
  const figure = await createPaintedFigure(base, opts);
  let body;
  try {
    body = kit.createBody(opts.host, { figure, words: CUSTOM_WORDS });
  } catch (e) {
    figure.dispose();
    throw e;
  }
  const nativeInspect = body.inspect.bind(body), nativeSet = body.set.bind(body);
  body.inspect = () => ({ ...nativeInspect(), figure: figure.inspect() });
  body.set = (settings = {}) => {
    if (Number.isFinite(settings.renderEdge)) figure.setRenderEdge(settings.renderEdge);
    nativeSet(settings);
  };
  globalThis.__maodouQARegister?.(body);
  return body;
}
export {
  createMaodouBody
};
